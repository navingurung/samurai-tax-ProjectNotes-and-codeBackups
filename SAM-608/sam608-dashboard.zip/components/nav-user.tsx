"use client";

import {
  IconDotsVertical,
  IconLogout,
  IconUserCircle,
} from "@tabler/icons-react";

import { Avatar, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";
import Link from "next/link";
import axios from "axios";

import { useRouter } from "next/navigation";
import { useTranslations } from "next-intl";

import { LoginCompanyContext } from "@/providers/LoginCompanyProvider";
import { useContext } from "react";
import { toast } from "sonner";
import { AlertCircle } from "lucide-react";
import { appSessionStorage } from "@/lib/app-storage";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL;
const CF_IMAGES_BASE_URL = process.env.NEXT_PUBLIC_CF_IMAGES_BASE_URL ?? "";

export function NavUser({
  user,
}: {
  user: {
    name: string;
    email: string;
    logoId?: string | null;
  };
}) {
  const { isMobile, setOpenMobile } = useSidebar();
  const t = useTranslations("auth");
  const context = useContext(LoginCompanyContext);
  if (!context) {
    throw new Error("NavUser must be used within a LoginCompanyProvider");
  }
  const { logout, loginType } = context;
  const router = useRouter();

  const handleLogout = async () => {
    try {
      // ログアウト中フラグをセット（axiosインターセプターのアラートを抑制）
      appSessionStorage.setItem("isLoggingOut", "true");
      // ログアウトAPIを呼び出す。ログインタイプに応じてエンドポイントを切り替える。
      const endpoint =
        loginType === "shop" ? "/auth/shop-logout" : "/auth/company-logout";
      await axios.post(
        `${API_BASE_URL}${endpoint}`,
        {},
        {
          withCredentials: true,
        },
      );
      //まずログアウト
      logout();
      // /loginへリダイレクト
      router.replace("/login");
    } catch (error: any) {
      console.error("Logout failed:", error);
      toast.custom((_toast) => (
        <div className="flex items-center gap-3 bg-white dark:bg-zinc-900 border border-red-300 rounded-lg px-4 py-3 shadow-lg">
          <AlertCircle className="h-5 w-5 text-red-500 shrink-0" />
          <p className="text-md text-red-600">{t("logoutFailed")}</p>
        </div>
      ));
    } finally {
      // ログアウト中フラグをクリア
      appSessionStorage.removeItem("isLoggingOut");
    }
  };

  return (
    <SidebarMenu>
      <SidebarMenuItem>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <SidebarMenuButton
              size="lg"
              className="data-[state=open]:bg-sidebar-accent data-[state=open]:text-sidebar-accent-foreground"
            >
              <Avatar className="h-8 w-8 rounded-lg grayscale">
                <AvatarImage
                  src={
                    user.logoId && CF_IMAGES_BASE_URL
                      ? `${CF_IMAGES_BASE_URL}/${user.logoId}/public`
                      : "/SAMURAITAX_logo_icon.png"
                  }
                  alt={user.name}
                />
              </Avatar>
              <div className="grid flex-1 text-left text-sm leading-tight">
                <span className="truncate font-medium">{user.name}</span>
                <span className="text-muted-foreground truncate text-xs">
                  {user.email}
                </span>
              </div>
              <IconDotsVertical className="ml-auto size-4" />
            </SidebarMenuButton>
          </DropdownMenuTrigger>
          <DropdownMenuContent
            className="w-(--radix-dropdown-menu-trigger-width) min-w-56 rounded-lg"
            side={isMobile ? "bottom" : "right"}
            align="end"
            sideOffset={4}
          >
            <DropdownMenuLabel className="p-0 font-normal">
              <div className="flex items-center gap-2 px-1 py-1.5 text-left text-sm">
                <Avatar className="h-8 w-8 rounded-lg">
                  <AvatarImage
                    src={
                      user.logoId && CF_IMAGES_BASE_URL
                        ? `${CF_IMAGES_BASE_URL}/${user.logoId}/public`
                        : "/SAMURAITAX_logo_icon.png"
                    }
                    alt={user.name}
                  />
                </Avatar>
                <div className="grid flex-1 text-left text-sm leading-tight">
                  <span className="truncate font-medium">{user.name}</span>
                  <span className="text-muted-foreground truncate text-xs">
                    {user.email}
                  </span>
                </div>
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuGroup>
              <DropdownMenuItem asChild className="cursor-pointer">
                <Link
                  href="/account"
                  onClick={() => {
                    if (isMobile) setOpenMobile(false);
                  }}
                >
                  <IconUserCircle />
                  {t("account")}
                </Link>
              </DropdownMenuItem>
            </DropdownMenuGroup>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={handleLogout} className="cursor-pointer">
              <IconLogout />
              <span>{t("logout")}</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </SidebarMenuItem>
    </SidebarMenu>
  );
}
