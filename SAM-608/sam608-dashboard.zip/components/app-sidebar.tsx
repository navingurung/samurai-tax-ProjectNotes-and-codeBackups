"use client";

import * as React from "react";
import {
  IconDashboard,
  IconHelp,
  IconPlugConnectedX,
} from "@tabler/icons-react";

import { NavMain } from "@/components/nav-main";
import { NavSecondary } from "@/components/nav-secondary";
import { NavUser } from "@/components/nav-user";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar";

import Image from "next/image";

import { LoginCompanyContext } from "@/providers/LoginCompanyProvider";
import { useContext } from "react";
import { NavDocuments } from "./nav-documents";
import { useTranslations } from "next-intl";
import { useIsShopifyEmbedded } from "@/hooks/use-shopify-embedded";

export function AppSidebar({ ...props }: React.ComponentProps<typeof Sidebar>) {
  const context = useContext(LoginCompanyContext);
  if (!context) {
    throw new Error("AppSidebar must be used within a LoginCompanyProvider");
  }
  const { loginCompany, loginShop, loginType } = context;
  const isEmbedded = useIsShopifyEmbedded();
  const t = useTranslations("sidebar");

  const data = {
    navMain: [
      {
        title: t("dashboard"),
        url: "/dashboard",
        icon: IconDashboard,
      },
          // {
    //   title: "レポート",
    //   url: "#",
    //   icon: IconReport,
    // },
    ],
    navSecondary: [
      {
        title: t("contact"),
        url: "/contact",
        icon: IconHelp,
      },
    ],
    documents: [
      {
        name: "Square",
        url: "/pos-integrations/square",
        icon: IconPlugConnectedX,
      },
    ],
  };

  const user = {
    name: loginType === "company" ? loginCompany?.name : loginShop?.name ?? "loading...",
    email: loginType === "company" ? loginCompany?.email : loginShop?.login_id ?? "loading...",
    logoId: loginType === "company" ? (loginCompany?.logo_id ?? null) : "loading...",
  };
  return (
    <Sidebar collapsible="offcanvas" {...props}>
      <SidebarHeader>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton
              asChild
              className="data-[slot=sidebar-menu-button]:p-1.5!"
            >
              <a href="/dashboard">
                <Image
                  src="/SAMURAITAX_logo_icon.png"
                  alt="SAMURAI TAX Logo"
                  width={24}
                  height={24}
                  className="rounded-sm"
                />
                <span className="text-base font-semibold tracking-tight">
                  SAMURAI TAX
                </span>
              </a>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarHeader>
      <SidebarContent>
        <NavMain items={data.navMain} />
        {/* ログインタイプが"shop"の場合はドキュメントナビを表示しない */}
        <NavDocuments items={loginType === "shop" || isEmbedded ? [] : data.documents} />
        <NavSecondary items={data.navSecondary} className="mt-auto" />
      </SidebarContent>
      <SidebarFooter>
        <NavUser user={user} />
      </SidebarFooter>
    </Sidebar>
  );
}
