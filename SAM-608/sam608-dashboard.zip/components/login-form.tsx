"use client";

import { cn } from "@/lib/utils";
import { FieldDescription } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { useRouter, useSearchParams } from "next/navigation";
import axios from "axios";
import { useState, useContext } from "react";
import { LoginCompanyContext } from "../providers/LoginCompanyProvider";
import { Spinner } from "@/components/ui/spinner";
import { motion, AnimatePresence } from "framer-motion";
import { AlertCircle } from "lucide-react";
import { toast } from "sonner";
import { useTranslations } from "next-intl";
import { LocaleSwitcher } from "@/components/locale-switcher";
import { appSessionStorage } from "@/lib/app-storage";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL;

//　①.a 店舗ログインと会社ログインで共通のフォームパネルのプロパティ
interface FormPanelProps {
  isShop: boolean;
  loginInfo: {
    login_id: string;
    login_password: string;
  };
  setLoginInfo: (value: { login_id: string; login_password: string }) => void;
  loading: boolean;
  onClickLogin: (e: React.MouseEvent<HTMLButtonElement>) => void;
  setLoginType: (value: "company" | "shop") => void;
}

// ①.b 店舗ログインと会社ログインで共通のフォームパネル
const FormPanel = ({
  setLoginType,
  isShop,
  loginInfo,
  setLoginInfo,
  loading,
  onClickLogin,
}: FormPanelProps) => {
  const t = useTranslations("auth");
  return (
    <div className="flex flex-col justify-center h-full px-8 py-10 relative overflow-hidden min-h-96 bg-white dark:bg-gray-800">
      {/* ------ カード：会社・店舗タイトル、ログインID、パスワード、ボタンなど ------ */}
      <div className="relative z-10 flex flex-col gap-5">
        {/* ------ タブ切り替えボタン：会社・店舗（モバイルのみ） ------ */}
        <div className="flex md:hidden rounded-lg border border-gray-200 p-1.5 gap-1">
          <button
            type="button"
            onClick={() => setLoginType("shop")}
            className={cn(
              "flex-1 rounded-md px-3 py-1.5 text-sm font-medium transition-colors",
              isShop
                ? "bg-[#164d86] text-white"
                : "text-gray-500 hover:text-gray-700 dark:hover:text-white",
            )}
          >
            {t("shop")}
          </button>
          <button
            type="button"
            onClick={() => setLoginType("company")}
            className={cn(
              "flex-1 rounded-md px-3 py-1.5 text-sm font-medium transition-colors",
              isShop
                ? "text-gray-500 hover:text-gray-700 dark:hover:text-white"
                : "bg-[#164d86] text-white",
            )}
          >
            {t("company")}
          </button>
        </div>
        {/*　======== ボタングルプを終了 ======== */}

        {/* ------ タイトル店舗・会社 ------ */}
        <div>
          <h2
            className={`text-lg font-bold dark:text-white ${isShop ? "text-[#121731e8]" : "text-[#164d86]"}`}
          >
            {isShop ? t("shopLogin") : t("companyLogin")}
          </h2>
          <p className="text-sm text-gray-500 dark:text-gray-300 mt-1">
            {isShop ? t("shopSubtitle") : t("companySubtitle")}
          </p>
        </div>
        {/*　======== タイトルを終了 ======== */}

        {/*　-------- 入力フィールドグループ：ID又はメールアドレス・パスワード -------- */}
        <div className="flex flex-col gap-4">
          {/* 入力フィールド：ID又はメールアドレス */}
          <div className="flex flex-col gap-1.5">
            <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
              {isShop ? t("id") : t("email")}
            </label>
            <Input
              type={isShop ? "text" : "email"}
              placeholder={isShop ? t("idPlaceholder") : t("emailPlaceholder")}
              value={loginInfo.login_id}
              onChange={(e) =>
                setLoginInfo({ ...loginInfo, login_id: e.target.value })
              }
              className="h-11 border-gray-200"
              required
            />
          </div>
          {/* ======== 入力フィールド：ID又はメールアドレス終了 ======== */}

          {/* -------- 入力フィールド：パスワード -------- */}
          <div className="flex flex-col gap-1.5">
            <label className="text-sm font-medium text-gray-700">
              {t("password")}
            </label>
            <Input
              type="password"
              placeholder="********"
              value={loginInfo.login_password}
              onChange={(e) =>
                setLoginInfo({ ...loginInfo, login_password: e.target.value })
              }
              className="h-11 border-gray-200"
              required
            />
          </div>
          {/* ======== 入力フィールド：パスワード終了 ======== */}
        </div>
        {/*　======== 入力フィールドグループ終了 ======== */}

        {/* -------- ログインボタン -------- */}
        <button
          type="submit"
          onClick={onClickLogin}
          disabled={loading}
          className={`w-full h-11 
            ${isShop ? "bg-[#121731e8] hover:bg-[#2c3877e8]" : "bg-[#164d86] hover:bg-[#1d69ba]"} 
            disabled:opacity-60 text-white font-semibold rounded-lg transition-colors 
            flex items-center justify-center cursor-pointer`}
        >
          {loading ? <Spinner className="h-4 w-4" /> : t("loginButton")}
        </button>
        {/*　======== ログインボタン終了 ======== */}
        {/* ========= アカウント作成リンク ========= */}
        {
          !isShop && (
            <div className="text-sm text-center text-gray-500 dark:text-gray-300 mt-2">
              {t("noAccount")}{" "}
              <a
                href="https://samurai-tax.com/contact"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#164d86] dark:text-white underline cursor-pointer"
              >
                {t("contactUs")}
              </a>
            </div>
          )
        }
        {/* ========= アカウント作成リンク終了 ========= */}
      </div>
    </div>
  );
};

// ②.a ブランドロゴと背景イメージを表示するパネルのプロパティ
interface BrandPanelProps {
  isShop: boolean;
  handleSwitch: () => void;
}

// ②.b ブランドロゴと背景イメージを表示するパネル

const BrandPanel = ({ isShop, handleSwitch }: BrandPanelProps) => {
  const t = useTranslations("auth");
  return (
    <div
      className={`flex flex-col items-center justify-center h-full px-8 py-10 
        relative overflow-hidden min-h-[420px] 
        ${isShop ? "bg-[#121731e8] dark:bg-[#282e4ae8]" : "bg-[#164d86]"}`}
    >
      {/*　ーーー コンテンツ(タイトル・サブタイトル・ボタン)セクション開始　ーーー */}
      <div className="relative z-10 flex flex-col items-center gap-6 w-full">
        {/* ------ タイトル・サブタイトルグループ ------ */}
        <div className="text-center">
          <h1 className="text-2xl font-bold text-white">{t("welcome")}</h1>
          <p className="text-white text-sm mt-1">SAMURAI TAX Dashboard</p>
        </div>
        {/* ======== タイトル・サブタイトルグループ終了 ======== */}

        {/* ------ ブランドロゴ ------ */}
        <img
          src="/SAMURAI_TAX_Logo_white.png"
          alt="SAMURAI TAX Logo white"
          className="w-80 m-auto object-contain"
        />
        {/* ======== ブランドロゴ終了 ======== */}

        {/* ----- 会社・店舗スライドを切り替えボタン ----- */}
        <button
          onClick={handleSwitch}
          className={`border-2 border-white text-white rounded-sm px-8 h-11 w-full hover:bg-white 
            ${isShop ? "hover:text-[#121731e8]" : "hover:text-[#164d86]"} transition-all duration-200 cursor-pointer`}
        >
          {isShop ? t("switchToCompany") : t("switchToShop")}
        </button>
        {/* ======== 会社・店舗スライドを切り替えボタン終了 ======== */}
      </div>
      {/*　＝＝＝＝ コンテンツ(タイトル・サブタイトル・ボタン)セクション終了　＝＝＝＝ */}
    </div>
  );
};

export function LoginForm({
  className,
  ...props
}: React.ComponentProps<"div">) {
  const t = useTranslations("auth");
  const context = useContext(LoginCompanyContext);
  if (!context) {
    throw new Error("LoginForm must be used within a LoginCompanyProvider");
  }
  const { setLoginCompany, setIsLoggedIn, setLoginShop } = context;
  const [loginInfo, setLoginInfo] = useState({
    login_id: "",
    login_password: "",
  });
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const searchParams = useSearchParams();
  const [loginType, setLoginType] = useState<"company" | "shop">("company");
  const isShop = loginType === "shop";
  const handleSwitch = () => {
    setLoginType(isShop ? "company" : "shop");
    setLoginInfo({ login_id: "", login_password: "" }); // フォームをリセット
  };

  const handleSetLoginType = (type: "company" | "shop") => {
    setLoginType(type);
    setLoginInfo({ login_id: "", login_password: "" }); // フォームをリセット
  };

  const onClickLogin = async (e: React.MouseEvent<HTMLButtonElement>) => {
    if (loading) return; // すでにログイン処理中なら何もしない
    if (!loginInfo.login_id || !loginInfo.login_password) {
      // エラートーストを表示(カストマイズ)
      toast.custom(
        (_toast) => (
          <div
            className="relative flex items-center gap-3 bg-white dark:bg-zinc-900 
                border border-red-200 rounded-lg px-5 py-3 shadow-lg"
          >
            <AlertCircle className="h-5 w-5 text-red-500 shrink-0" />
            <p className="text-sm text-red-600 pr-4">
              {isShop
                ? t("emptyShopError")
                : t("emptyCompanyError")}
            </p>
          </div>
        ),
        { position: "top-center" },
      );
      return;
    }
    e.preventDefault(); // ← これ超重要
    setLoading(true);
    try {
      const params = new URLSearchParams();
      params.append("username", loginInfo.login_id);
      params.append("password", loginInfo.login_password);

      // ログインタイプに応じてAPIエンドポイントを切り替え: companyの場合は /auth/company-token、shopの場合は /auth/shop-token
      if (loginType === "company") {
        const response = await axios.post(
          `${API_BASE_URL}/auth/company-token`,
          params,
          {
            headers: {
              "Content-Type": "application/x-www-form-urlencoded",
            },
            withCredentials: true,
          },
        );
        setLoginCompany(response.data);
        appSessionStorage.setItem("authCompany", JSON.stringify(response.data));
        // 店舗セッションをクリア
        appSessionStorage.removeItem("authShop");
        setLoginShop(null);
      } else {
        const response = await axios.post(
          `${API_BASE_URL}/auth/shop-token`,
          params,
          {
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            withCredentials: true,
          },
        );
        setLoginShop(response.data);
        appSessionStorage.setItem("authShop", JSON.stringify(response.data));
        // 会社セッションをクリア
        appSessionStorage.removeItem("authCompany");
        setLoginCompany(null);
      }
      setIsLoggedIn(true);

      // リダイレクト先を取得（なければ /dashboard）
      const redirectTo = searchParams.get("redirect") || "/dashboard";
      router.push(redirectTo);
    } catch (error) {
      console.error(error);
      // エラートーストを表示(カストマイズ)
      toast.custom(
        (_toast) => (
          <div
            className="relative flex items-center gap-3 bg-white dark:bg-zinc-900 
                border border-red-200 rounded-lg px-4 py-3 shadow-lg"
          >
            <AlertCircle className="h-5 w-5 text-red-500 shrink-0" />
            <p className="text-sm text-red-600 pr-4">
              {isShop
                ? t("wrongShopError")
                : t("wrongCompanyError")}
            </p>
          </div>
        ),
        { position: "top-center" },
      );
    } finally {
      setLoading(false);
    }
  };

  const formPros = {
    isShop,
    loginInfo,
    setLoginInfo,
    loading,
    onClickLogin,
    setLoginType: handleSetLoginType,
  };
  const brandPros = { isShop, handleSwitch };
  return (
    <div className={cn("flex flex-col gap-6", className)} {...props}>
      <div className="overflow-hidden rounded-2xl shadow-lg">
        <div className="grid grid-cols-1 md:grid-cols-2 min-h-[440px]">
          {/* 携帯の場合は入力フォームのみを表示 */}
          <div
            className="block md:hidden h-full"
            data-testid="mobile-login-panel"
          >
            <FormPanel {...formPros} />
          </div>
          {/* ---- 携帯のみ表示終了 ---- */}

          {/* タブレット以上の場合は左右に分割して表示 */}
          <div className="hidden md:block h-full">
            <AnimatePresence mode="wait">
              <motion.div
                key={isShop ? "left-form" : "left-brand"}
                initial={{ opacity: 0, x: isShop ? -50 : 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: isShop ? 40 : -40 }}
                transition={{ duration: 0.3, ease: "easeInOut" }}
                className="h-full"
              >
                {isShop ? (
                  <FormPanel {...formPros} />
                ) : (
                  <BrandPanel {...brandPros} />
                )}
              </motion.div>
            </AnimatePresence>
          </div>

          <div className="hidden md:block h-full">
            <AnimatePresence mode="wait">
              <motion.div
                key={isShop ? "right-form" : "right-brand"}
                initial={{ opacity: 0, x: isShop ? -50 : 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: isShop ? 40 : -40 }}
                transition={{ duration: 0.3, ease: "easeInOut" }}
                className="h-full"
              >
                {isShop ? (
                  <BrandPanel {...brandPros} />
                ) : (
                  <FormPanel {...formPros} />
                )}
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>
      <FieldDescription className="px-6 text-center">
        {t("terms")}{" "}
        <a href="https://samurai-tax.com/terms" target="_blank" rel="noopener noreferrer">{t("termsLink")}</a> {t("and")}{" "}
        <a href="https://samurai-tax.com/privacy-policy" target="_blank" rel="noopener noreferrer ">{t("privacyLink")}</a>{" "}
        {t("termsAgreement")}
      </FieldDescription>
      <div className="flex justify-end items-center">
        <span className="text-sm text-gray-500 dark:text-gray-300 mr-2">
          {t("language")}
        </span>
        <LocaleSwitcher />
      </div>
    </div>
  );
}
