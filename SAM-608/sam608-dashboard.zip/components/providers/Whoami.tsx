"use client";

import { useEffect, useContext, useRef } from "react";
import axios from "axios";
import "@/lib/axios";
import { useRouter, usePathname } from "next/navigation";
import { LoginCompanyContext } from "@/providers/LoginCompanyProvider";
import { appSessionStorage } from "@/lib/app-storage";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL;

export const Whoami = () => {
  const context = useContext(LoginCompanyContext);
  const router = useRouter();
  const pathname = usePathname();
  const hasChecked = useRef(false);

  if (!context) {
    throw new Error("Whoami must be used within a LoginCompanyProvider");
  }

  const {
    setLoginCompany,
    setLoginShop,
    setIsLoggedIn,
    isInitialized,
    setIsAuthChecking,
    logout,
  } = context;

  useEffect(() => {
    // 初期化完了後、まだチェックしていない場合のみアクセストークンの検証を実行（sessionStorageの有無は判定条件にしない）
    if (isInitialized && !hasChecked.current) {
      hasChecked.current = true;

      setIsAuthChecking(true);

      // セッションストレージの情報からログインタイプを推測（ヒントとして使用、判定条件としては使わない）
      const isShopSession =
        typeof window !== "undefined" &&
        !!appSessionStorage.getItem("authShop") &&
        !appSessionStorage.getItem("authCompany");

      // 会社アカウントとしてCookieを検証
      const tryCompany = () =>
        axios
          .get(`${API_BASE_URL}/auth/company-whoami`, { withCredentials: true })
.then((res) => {
  const { login_id, company_id, name, email, logo_id } = res.data;
  // ensure the other login type is cleared to avoid stale mixed state
  setLoginShop(null);
  setLoginCompany({ login_id, company_id, name, email, logo_id });
  setIsLoggedIn(true);
});

      // 店舗アカウントとしてCookieを検証
      const tryShop = () =>
        axios
          .get(`${API_BASE_URL}/auth/shop-whoami`, { withCredentials: true })
.then((res) => {
  const { shop_id, name, login_id } = res.data;
  // ensure the other login type is cleared to avoid stale mixed state
  setLoginCompany(null);
  setLoginShop({ shop_id, name, login_id });
  setIsLoggedIn(true);
});

      // 先に試すアカウントタイプを決定（外れた場合はもう一方を試す）
      const first = isShopSession ? tryShop : tryCompany;
      const second = isShopSession ? tryCompany : tryShop;

      //どちらのアカウントとしても認証できなかった場合はログアウトし、/login以外にいる場合のみリダイレクト
      first()
        .catch(() => second())
        .catch((error) => {
          if (error.response?.status === 401) {
            logout();
            if (pathname !== "/login") {
              router.replace(`/login?redirect=${encodeURIComponent(pathname)}`);
            }
          } else {
            console.error("Failed to verify authentication:", error);
          }
        })
        .finally(() => setIsAuthChecking(false));
    }

    // パスが変わったらチェックフラグをリセット
    return () => {
      if (pathname === "/login") {
        hasChecked.current = false;
      }
    };
  }, [
    isInitialized,
    pathname,
    setLoginCompany,
    setLoginShop,
    setIsLoggedIn,
    setIsAuthChecking,
    logout,
    router,
  ]);

  return null;
};
