// Shopify埋め込み時はブラウザストレージを使わず、メモリに保持する（App Store ルール 1.1.1）
// 埋め込みでない通常のダッシュボードでは、これまで通り sessionStorage / localStorage を使う
import { isShopifyEmbedded } from "@/lib/shopify-embedded";

type StorageLike = Pick<Storage, "getItem" | "setItem" | "removeItem">;

const createStorage = (getBrowserStorage: () => Storage): StorageLike => {
  const memory = new Map<string, string>();
  const target = (): StorageLike =>
    isShopifyEmbedded()
      ? {
          getItem: (key) => memory.get(key) ?? null,
          setItem: (key, value) => void memory.set(key, value),
          removeItem: (key) => void memory.delete(key),
        }
      : getBrowserStorage();

  return {
    getItem: (key) => target().getItem(key),
    setItem: (key, value) => target().setItem(key, value),
    removeItem: (key) => target().removeItem(key),
  };
};

export const appSessionStorage = createStorage(() => window.sessionStorage);
export const appLocalStorage = createStorage(() => window.localStorage);