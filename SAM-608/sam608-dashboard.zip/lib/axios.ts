import axios, {
  type AxiosError,
  type AxiosInstance,
  type InternalAxiosRequestConfig,
} from "axios";
import {
  getShopifySessionToken,
  isShopifyEmbedded,
} from "@/lib/shopify-embedded";
import { appSessionStorage } from "@/lib/app-storage";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL;

// axios インスタンスを作成
export const axiosInstance = axios.create({
  baseURL: API_BASE_URL,
  withCredentials: true,
});

type ShopifyRetryConfig = InternalAxiosRequestConfig & {
  _shopifyRetried?: boolean;
};

// 自社APIへのリクエストのみトークンを付与する（外部URLには送らない）
const isApiRequest = (config: InternalAxiosRequestConfig) =>
  !!API_BASE_URL && axios.getUri(config).startsWith(API_BASE_URL);

// Shopify埋め込み時: リクエストごとに新しいセッショントークンを付与（SAM-612）
const attachShopifyToken = async (config: InternalAxiosRequestConfig) => {
  if (isShopifyEmbedded() && isApiRequest(config)) {
    const token = await getShopifySessionToken();
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
};

// Shopify埋め込み時: 401なら新しいトークンで1回だけ再試行する（SAM-612）
const retryWithFreshToken = (error: AxiosError, client: AxiosInstance) => {
  const config = error.config as ShopifyRetryConfig | undefined;
  if (
    !isShopifyEmbedded() ||
    error.response?.status !== 401 ||
    !config ||
    config._shopifyRetried
  ) {
    return null;
  }
  config._shopifyRetried = true;
  return client(config);
};

axiosInstance.interceptors.request.use(attachShopifyToken);
// login-form / Whoami / nav-user は axios を直接使うため、デフォルトにも設定する
axios.interceptors.request.use(attachShopifyToken);
axios.interceptors.response.use(
  (response) => response,
  (error: AxiosError) =>
    retryWithFreshToken(error, axios) ?? Promise.reject(error),
);

// レスポンスインターセプターを設定
axiosInstance.interceptors.response.use(
  (response) => {
    // 正常なレスポンスはそのまま返す
    return response;
  },
  (error) => {
    // Shopify埋め込み時は、先に新しいトークンで再試行する
    const retry = retryWithFreshToken(error, axiosInstance);
    if (retry) return retry;

    // 401エラー（認証エラー）の場合
    if (error.response?.status === 401) {
      if (typeof window !== "undefined") {
        const isLoggingOut = appSessionStorage.getItem("isLoggingOut");

        // ログアウト中の場合は何もしない
        if (isLoggingOut) return Promise.reject(error);

        // セッション切れの場合のみアラートを表示
        alert("セッションが切れました。再度ログインしてください。");

        // 会社セッションをクリア
        appSessionStorage.removeItem("authCompany");
        // 店舗セッションをクリア
        appSessionStorage.removeItem("authShop");
        // ログアウト中フラグをクリア（念のため）
        appSessionStorage.removeItem("isLoggingOut");

        const currentPath = window.location.pathname;
        if (currentPath !== "/login") {
          window.location.href = `/login?redirect=${encodeURIComponent(currentPath)}`;
        }
      }
    }

    // エラーをそのまま返す
    return Promise.reject(error);
  },
);

export default axiosInstance;
