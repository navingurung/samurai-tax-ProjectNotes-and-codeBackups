// Shopify管理画面内（/shopify/app の iframe）での動作判定と、
// 親フレームからのセッショントークン取得（SAM-612）

const TOKEN_TIMEOUT_MS = 5000;
const REQUEST_TYPE = "samurai:id-token:request";
const RESPONSE_TYPE = "samurai:id-token:response";

// 親フレーム（/shopify/app）のオリジン。未設定の場合は埋め込みとして扱わない
const APP_ORIGIN = (() => {
  const raw = process.env.NEXT_PUBLIC_SHOPIFY_APP_ORIGIN;
  if (!raw) return null;
  try {
    return new URL(raw).origin;
  } catch {
    return null;
  }
})();

// 通常のダッシュボードは iframe で表示されないため、iframe 内なら Shopify 埋め込みと判定する
export const isShopifyEmbedded = (): boolean =>
  typeof window !== "undefined" && !!APP_ORIGIN && window.self !== window.top;

// 親フレームに postMessage でセッショントークンを要求する（約1分で失効するため毎回取得）
export const getShopifySessionToken = (): Promise<string> =>
  new Promise((resolve, reject) => {
    if (!isShopifyEmbedded() || !APP_ORIGIN) {
      reject(new Error("Not embedded in Shopify admin"));
      return;
    }

    const requestId = crypto.randomUUID();

    const cleanup = () => {
      window.clearTimeout(timer);
      window.removeEventListener("message", onMessage);
    };

    const timer = window.setTimeout(() => {
      cleanup();
      reject(new Error("Shopify session token request timed out"));
    }, TOKEN_TIMEOUT_MS);

    function onMessage(event: MessageEvent) {
      // 親フレーム（/shopify/app）からの、この要求への返信のみ受け付ける
      if (event.origin !== APP_ORIGIN || event.source !== window.parent) return;
      const data = event.data;
      if (data?.type !== RESPONSE_TYPE || data.requestId !== requestId) return;

      cleanup();
      if (typeof data.token === "string" && data.token) {
        resolve(data.token);
      } else {
        reject(new Error(data.error || "Failed to get Shopify session token"));
      }
    }

    window.addEventListener("message", onMessage);
    window.parent.postMessage({ type: REQUEST_TYPE, requestId }, APP_ORIGIN);
  });
