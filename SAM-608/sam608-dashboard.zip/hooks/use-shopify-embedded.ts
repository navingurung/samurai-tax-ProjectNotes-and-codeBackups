import { useSyncExternalStore } from "react";
import { isShopifyEmbedded } from "@/lib/shopify-embedded";

// Shopify管理画面内かどうか（サーバー描画では false、ハイドレーション後に実際の値）
const subscribe = () => () => {};

export const useIsShopifyEmbedded = (): boolean =>
  useSyncExternalStore(subscribe, isShopifyEmbedded, () => false);