import type { NextConfig } from "next";
import createNextIntlPlugin from "next-intl/plugin";

const withNextIntl = createNextIntlPlugin("./i18n/request.ts");

// Shopify管理画面内（/shopify/app → admin.shopify.com）からの iframe 表示のみ許可する（SAM-612）
// ブラウザは親フレームすべてを確認するため、/shopify/app と Shopify 管理画面の両方が必要
const shopifyAppOrigin = (() => {
  try {
    return new URL(process.env.NEXT_PUBLIC_SHOPIFY_APP_ORIGIN ?? "").origin;
  } catch {
    return null;
  }
})();
const frameAncestors = ["https://admin.shopify.com", shopifyAppOrigin]
  .filter(Boolean)
  .join(" ");

const nextConfig: NextConfig = {
  output: "standalone",
  async headers() {
    return [
      {
        source: "/:path*",
        headers: [
          {
            key: "Content-Security-Policy",
            value: `frame-ancestors ${frameAncestors};`,
          },
        ],
      },
    ];
  },
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "imagedelivery.net",
      },
    ],
  },
};

export default withNextIntl(nextConfig);