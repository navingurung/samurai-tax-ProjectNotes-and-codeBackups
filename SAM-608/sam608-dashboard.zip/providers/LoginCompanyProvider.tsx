"use client";

import {
  createContext,
  useCallback,
  useState,
  useEffect,
  ReactNode,
} from "react";

import { appSessionStorage } from "@/lib/app-storage";
export interface LoginCompanyContextType {
  loginCompany: any;
  loginShop: any;
  setLoginCompany: (company: any) => void;
  setLoginShop: (shop: any) => void;
  loginType: "company" | "shop" | null;
  isLoggedIn: boolean;
  setIsLoggedIn: (isLoggedIn: boolean) => void;
  isInitialized: boolean;
  isAuthChecking: boolean;
  setIsAuthChecking: (isChecking: boolean) => void;
  logout: () => void;
}

export const LoginCompanyContext = createContext<
  LoginCompanyContextType | undefined
>(undefined);

export const LoginCompanyProvider = ({ children }: { children: ReactNode }) => {
  // ハイドレーションエラーを防ぐため、初期値は常にnull/falseにする
  const [loginCompany, setLoginCompany] = useState<any>(null);
  const [loginShop, setLoginShop] = useState<any>(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isInitialized, setIsInitialized] = useState(false);
  const [isAuthChecking, setIsAuthChecking] = useState(false);

  // ログインタイプを判定（会社・店舗）
  const loginType = loginCompany ? "company" : loginShop ? "shop" : null;

  // マウント後にsessionStorageから状態を復元
  useEffect(() => {
    if (typeof window !== "undefined") {
      // sessionStorageから会社の状態を復元
      const raw = appSessionStorage.getItem("authCompany");
      if (raw) {
        try {
          const data = JSON.parse(raw);
          setLoginCompany(data);
          setIsLoggedIn(true);
        } catch (error) {
          console.error(
            "Failed to parse authCompany from sessionStorage",
            error,
          );
          appSessionStorage.removeItem("authCompany");
        }
      }
      // 同様に、shopの状態も復元
      const rawShop = appSessionStorage.getItem("authShop");
      if (rawShop) {
        try {
          const data = JSON.parse(rawShop);
          setLoginShop(data);
          setIsLoggedIn(true);
        } catch (error) {
          console.error("Failed to parse authShop from sessionStorage", error);
          appSessionStorage.removeItem("authShop");
        }
      }
      setIsInitialized(true);
    }
  }, []);

  // authCompanyをsessionStorageに保存
  useEffect(() => {
    if (typeof window !== "undefined") {
      if (loginCompany) {
        appSessionStorage.setItem("authCompany", JSON.stringify(loginCompany));
        setIsLoggedIn(true);
      } else {
        appSessionStorage.removeItem("authCompany");
        if (!loginShop) setIsLoggedIn(false);
      }
    }
  }, [loginCompany]);

  // authShopをsessionStorageに保存
  useEffect(() => {
    if (typeof window !== "undefined") {
      if (loginShop) {
        appSessionStorage.setItem("authShop", JSON.stringify(loginShop));
        setIsLoggedIn(true);
      } else {
        appSessionStorage.removeItem("authShop");
        if (!loginCompany) setIsLoggedIn(false);
      }
    }
  }, [loginShop]);

  // Whoami.tsxのuseEffectが不要に再実行されないよう、関数の参照を安定させる
  const logout = useCallback(() => {
    if (typeof window !== "undefined") {
      appSessionStorage.removeItem("authCompany");
      appSessionStorage.removeItem("authShop");
    }
    setLoginCompany(null);
    setLoginShop(null);
  }, []);
  return (
    <LoginCompanyContext.Provider
      value={{
        loginCompany,
        setLoginCompany: setLoginCompany,
        isLoggedIn,
        setIsLoggedIn: setIsLoggedIn,
        isInitialized,
        isAuthChecking,
        setIsAuthChecking: setIsAuthChecking,
        logout,
        loginShop,
        setLoginShop: setLoginShop,
        loginType,
      }}
    >
      {children}
    </LoginCompanyContext.Provider>
  );
};
