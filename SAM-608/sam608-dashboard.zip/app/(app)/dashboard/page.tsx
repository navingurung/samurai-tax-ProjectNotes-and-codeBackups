"use client";
import { useSimulatedProgress } from "@/hooks/use-simulated-progress";
import { LoadingOverlay } from "@/components/loading-overlay";
import { useRouter, useSearchParams, usePathname } from "next/navigation";
import { ChartAreaInteractive } from "@/components/chart-area-interactive";
import { ChartByNation } from "@/components/chart-by-nation";
import { DataTable } from "@/components/data-table/data-table";
import { SectionCards } from "@/components/section-cards";
import { SiteHeader } from "@/components/site-header";
import { Filter } from "@/components/filter";

import React, { useEffect, useMemo, useState, useRef } from "react";
import { DashboardSchema, Store, SelectedStore } from "@/lib/schemas";
import { CANCELLED_STATUSES, Status } from "@/lib/constants/status";
import { format } from "date-fns";
import { type DateRange } from "react-day-picker";
import { type DateTimeRangeFilter } from "@/components/date-picker";
import { toast } from "sonner";
import axiosInstance from "@/lib/axios";

import { LoginCompanyContext } from "@/providers/LoginCompanyProvider";
import { useContext } from "react";
import { appSessionStorage, appLocalStorage } from "@/lib/app-storage";
import { motion } from "framer-motion";
import { useTranslations } from "next-intl";
import { AlertCircle, X } from "lucide-react";

export const filterByTimeRange = (
  data: DashboardSchema[],
  filter: DateTimeRangeFilter | undefined,
) => {
  if (!filter?.useTime || !filter.date?.from) return data;

  const [fh, fm] = filter.fromTime.split(":").map(Number);
  const [th, tm] = filter.toTime.split(":").map(Number);

  // 開始時間と終了時間を分単位に変換
  const startMinutes = fh * 60 + fm;
  const endMinutes = th * 60 + tm;

  return data.filter((item) => {
    const jst = new Date(
      new Date(item.createdAt).getTime() + 9 * 60 * 60 * 1000,
    );
    const itemMinutes = jst.getHours() * 60 + jst.getMinutes();

    if (endMinutes >= startMinutes) {
      // 例）10:00〜18:00 の場合
      return itemMinutes >= startMinutes && itemMinutes <= endMinutes;
    } else {
      // 日付またぎ：例）23:00〜02:00 の場合
      return itemMinutes >= startMinutes || itemMinutes <= endMinutes;
    }
  });
};

export default function Page() {
  const context = useContext(LoginCompanyContext);
  if (!context) {
    throw new Error("Page must be used within a LoginCompanyProvider");
  }

  const t = useTranslations("dashboard");

  // URLパラメータの取得とルーターの準備(目的：日付範囲や店舗フィルタをURLに反映させるため)
  const router = useRouter();
  const searchParams = useSearchParams();
  const pathname = usePathname();
  // ログイン情報を取得
  const { loginCompany, loginShop, loginType } = context;
  const [isReady, setIsReady] = useState(false);
  const [date, setDate] = useState<DateRange | undefined>(undefined);
  const [rawData, setRawData] = useState<DashboardSchema[]>(() => {
    return [] as DashboardSchema[];
  });
  const [stores, setStores] = useState<Store[]>([]);
  const [selectedStore, setSelectedStore] = useState<SelectedStore>({
    storeIds: [],
  });

  const [dateFilter, setDateFilter] = useState<DateTimeRangeFilter | undefined>(
    undefined,
  );

  const [fetchStatus, setFetchStatus] = useState<
    "idle" | "loading" | "success" | "error"
  >("idle");
  const progress = useSimulatedProgress(
    fetchStatus === "loading" ? "loading" : fetchStatus,
  );

  // まずキャンセル系（"refunded"/"cancelled"）を除いたものだけをフィルタリング（店舗選択に依存しない共通ベース）
  const nonRefundedData = useMemo(
    () =>
      rawData.filter(
        (item) => !CANCELLED_STATUSES.includes(item.status as Status),
      ),
    [rawData],
  );

  const filteredData = useMemo(() => {
    // その後、店舗でフィルタリング
    if (selectedStore.storeIds.length === 0) {
      return nonRefundedData;
    }
    return nonRefundedData.filter((item) =>
      selectedStore.storeIds.includes(String(item.shopId)),
    );
  }, [nonRefundedData, selectedStore.storeIds]);

  const timeFilteredData = useMemo(
    () => filterByTimeRange(filteredData, dateFilter),
    [filteredData, dateFilter],
  );

  // テーブル表示用：店舗フィルタのみ適用し、キャンセル/取消は除外しない（KPIとは別系統）
  const filteredDataForTable = useMemo(() => {
    if (selectedStore.storeIds.length === 0) {
      return rawData;
    }
    return rawData.filter((item) =>
      selectedStore.storeIds.includes(String(item.shopId)),
    );
  }, [rawData, selectedStore.storeIds]);

  // テーブル表示用：時間帯フィルタ（KPIと同じロジックだが、キャンセル/取消を含んだデータに対して適用）
  const timeFilteredDataForTable = useMemo(
    () => filterByTimeRange(filteredDataForTable, dateFilter),
    [filteredDataForTable, dateFilter],
  );

  // 店舗選択に依存しない時間帯フィルタ済みデータ（ドロップダウンの店舗別件数集計専用）
  const timeFilteredAllStoresData = useMemo(
    () => filterByTimeRange(nonRefundedData, dateFilter),
    [nonRefundedData, dateFilter],
  );

  // 店舗ごとの免税件数を付与した store リスト（ドロップダウンの棒グラフ表示用、選択状態に影響されない）
  const storesWithCount = useMemo(() => {
    const countByStore = timeFilteredAllStoresData.reduce<
      Record<string, number>
    >((acc, item) => {
      acc[item.shopId] = (acc[item.shopId] ?? 0) + 1;
      return acc;
    }, {});
    return stores.map((store) => ({
      ...store,
      taxFreeCount: countByStore[store.storeId] ?? 0,
    }));
  }, [stores, timeFilteredAllStoresData]);

  const sortedData = useMemo(() => {
    return [...timeFilteredDataForTable].sort(
      (a, b) => new Date(b.id).getTime() - new Date(a.id).getTime(),
    );
  }, [timeFilteredDataForTable]);

  const aggregatedData = useMemo(() => {
    // ① まず日別集計
    const aggregation: Record<
      string,
      { totalAmount: number; totalTax: number; count: number }
    > = {};
    timeFilteredData.forEach((item) => {
      const itemDate = format(new Date(item.createdAt), "yyyy-MM-dd");
      if (!aggregation[itemDate]) {
        aggregation[itemDate] = { totalAmount: 0, totalTax: 0, count: 0 };
      }
      if (CANCELLED_STATUSES.includes(item.status as Status)) {
        return; // refundedとキャンセルは集計に含めない
      }
      aggregation[itemDate].totalAmount += item.totalAmount;
      aggregation[itemDate].totalTax += item.totalTax;
      aggregation[itemDate].count += 1; // 件数をカウント
    });
    // ② 表示したい日付範囲を決める
    if (!date?.from || !date?.to) {
      // 範囲未指定なら、集計結果だけ返す
      return Object.entries(aggregation).map(([date, values]) => ({
        date,
        totalAmount: values.totalAmount,
        totalTax: values.totalTax,
        count: values.count,
      }));
    }
    // ③ from〜to の全日付を生成して穴埋め
    const result = [];
    const current = new Date(date.from);
    const end = new Date(date.to);
    while (current <= end) {
      const dateKey = format(current, "yyyy-MM-dd");
      const values = aggregation[dateKey] ?? {
        totalAmount: 0,
        totalTax: 0,
        count: 0,
      };
      result.push({
        date: dateKey,
        totalAmount: values.totalAmount,
        totalTax: values.totalTax,
        count: values.count,
      });
      current.setDate(current.getDate() + 1);
    }
    return result;
  }, [timeFilteredData, date]);

  // 同時に複数のリクエストが発生した場合に、古いリクエストの結果で
  // 新しいリクエストの結果を上書きしないようにするためのリクエストID管理
  const requestIdRef = useRef(0);

  // 必要に応じてAPIからデータを取得する関数。日付範囲と店舗IDでフィルタリングして取得。
  // shopId は loginType === "shop"（店舗単体ログイン）のアクセス制御専用。
  // 会社ログインの店舗フィルタ（selectedStore）はここでは使わず、常に全店舗データを取得しクライアント側でフィルタする。
  const getRefundList = async (from?: Date, to?: Date, shopId?: string) => {
    // ログアウト中はAPI呼び出しをスキップ
    if (appSessionStorage.getItem("isLoggingOut")) return;

    // このリクエスト固有のIDを発行(呼び出すたびにカウントアップ)
    const currentRequestId = ++requestIdRef.current;

    setFetchStatus("loading");
    try {
      const response = await axiosInstance.get(
        `/refundlist/transactions-by-date/`,
        {
          // APIのクエリパラメータとして日付範囲と店舗IDを渡す
          params: {
            from_date: from ? format(from, "yyyy-MM-dd") : undefined,
            to_date: to ? format(to, "yyyy-MM-dd") : undefined,
            ...(shopId !== undefined && { shop_id: shopId }),
          },
          withCredentials: true,
        },
      );
      if (currentRequestId !== requestIdRef.current) return; // 古いリクエストの結果は無視する
      setRawData(response.data);
      setFetchStatus("success");
    } catch (error) {
      if (currentRequestId !== requestIdRef.current) return; // 古いリクエストのエラーは無視する
      console.error("Error fetching refund list:", error);
      // エラー時にカスタムトーストを表示
      toast.custom(
        (t) => (
          <div className="relative flex items-center gap-3 bg-white dark:bg-red-900 border border-red-200 dark:border-red-800 rounded-lg px-5 py-3 sm:px-6 sm:py-4 shadow-lg sm:whitespace-nowrap">
            <AlertCircle className="h-5 w-5 text-red-500 dark:text-white shrink-0" />
            <p className="text-sm text-red-600 dark:text-white pr-4">
              データの取得に失敗しました。もう一度お試しください。
            </p>
            <button
              onClick={() => toast.dismiss(t)}
              className="absolute top-1.5 right-1.5 text-zinc-400 dark:text-white/70 hover:text-zinc-600 dark:hover:text-white"
            >
              <X className="h-4 w-4 cursor-pointer" />
            </button>
          </div>
        ),
        { position: "top-center", duration: 6000 },
      );
      setFetchStatus("error");
    }
  };

  const getStores = async () => {
    if (!loginCompany?.company_id) return; // company_idが存在しない場合は処理しない

    try {
      const response = await axiosInstance.get(
        `/shop/company-shopslist/${loginCompany.company_id}`,
        {
          withCredentials: true,
        },
      );
      const storeNames = response.data.map((shop: any) => ({
        storeId: String(shop.id),
        storeName: shop.shop_name, //
      }));
      setStores(storeNames);
    } catch (error: any) {
      if (error?.response?.status === 404) {
        setStores([]);
      } else {
        console.error("Error fetching stores:", error);
      }
    }
  };

  // 初回のURLパラメータの反映とデータ取得を制御するためのフラグ
  const hasInitialized = useRef(false);
  // ① loginCompanyが設定されるのを待つ（必要なAPIリクエストのため） ② URLパラメータを反映させて状態を初期化 ③ データを取得して準備完了
  useEffect(() => {
    if (!loginCompany && !loginShop) return; // loginCompanyまたはloginShopが設定されるまで待つ
    if (hasInitialized.current) return; // 2回目以降の実行はスキップ
    hasInitialized.current = true;
    const urlFrom = searchParams.get("from_date");
    const urlTo = searchParams.get("to_date");
    const urlShopIds = searchParams.get("shop_ids");

    // URLにshop_idがある場合はselectedStoreを更新
    if (urlShopIds) {
      setSelectedStore({
        storeIds: urlShopIds.split(",").map((id) => id.trim()),
      });
    }
    if (urlFrom && urlTo) {
      // URLパラメータが存在する場合はそれを優先して日付範囲を設定
      setDate({
        from: new Date(urlFrom),
        to: new Date(urlTo),
      });
    } else {
      // デフォルトのfrom日付を月初にする関数(目的：何も指定されてない場合は月の初めから今日までのデータを表示するため)
      const getDefaultFromDate = () => {
        const now = new Date();
        return new Date(now.getFullYear(), now.getMonth(), 1);
      };

      // URLパラメータがない場合はローカルストレージから日付範囲を復元。復元できない場合はデフォルト値を設定。
      const storageKey =
        loginType === "shop"
          ? "dashboardDateRange_shop"
          : "dashboardDateRange_company";

      // URLパラメータがない場合はローカルストレージから日付範囲を復元。復元できない場合はデフォルト値を設定。
      const saved = appLocalStorage.getItem(storageKey);

      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          setDate({
            from: parsed.from ? new Date(parsed.from) : getDefaultFromDate(),
            to: parsed.to ? new Date(parsed.to) : new Date(),
          });
          if (parsed.shopIds?.length > 0) {
            setSelectedStore({
              storeIds: parsed.shopIds.map((id: any) => String(id)),
            });
          }
        } catch {
          setDate({
            from: getDefaultFromDate(),
            to: new Date(),
          });
        }
      } else {
        setDate({
          from: getDefaultFromDate(),
          to: new Date(),
        });
      }
    }

    if (loginType === "shop" && loginShop) {
      setSelectedStore({ storeIds: [String(loginShop.shop_id)] });
    } else {
      getStores();
    }
    setIsReady(true);
  }, [loginCompany, loginShop]); // loginCompanyとloginShopが利用可能になったときに実行

  // 日付や店舗の選択が変わるたびにURLとローカルストレージを更新してデータを再取得するためのエフェクト。両方の状態を依存関係に入れることが重要。
  useEffect(() => {
    if (!date?.from || !date?.to) return;
    if (!loginType) return; // loginTypeが確定するまで待つ
    // 日付範囲と店舗IDをローカルストレージに保存（目的：ユーザーがページを離れても選択状態を保持するため）
    const storageKey =
      loginType === "shop"
        ? "dashboardDateRange_shop"
        : "dashboardDateRange_company";
    appLocalStorage.setItem(
      storageKey,
      JSON.stringify({
        from: date.from.toISOString(),
        to: date.to.toISOString(),
        shopIds: selectedStore.storeIds,
      }),
    );

    // URLSearchParamsを使ってURLに日付範囲と店舗IDを反映（目的：ユーザーがURLを共有したときに同じフィルタ状態を再現できるようにするため）
    const params = new URLSearchParams();
    params.set("from_date", format(date.from, "yyyy-MM-dd"));
    params.set("to_date", format(date.to, "yyyy-MM-dd"));
    if (selectedStore.storeIds.length > 0) {
      params.set("shop_ids", selectedStore.storeIds.join(","));
    }

    // URLを更新（目的：ユーザーがURLを共有したときに同じフィルタ状態を再現できるようにするため）
    router.replace(`${pathname}?${params.toString()}`);
    getRefundList(
      date.from,
      date.to,
      loginType === "shop" && loginShop?.shop_id != null
        ? String(loginShop.shop_id)
        : undefined,
    );
  }, [date, selectedStore, loginType]); // 日付範囲や店舗の選択が変わるたびに実行

  if (!isReady) {
    return null; // or <SkeletonDashboard />
  }

  return (
    <>
      <SiteHeader title={t("title")} />
      {progress > 0 && <LoadingOverlay progress={progress} />}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 0.5 }}
      >
        <div className="flex flex-1 flex-col">
          <div className="@container/main flex flex-1 flex-col gap-2">
            <div className="flex flex-col gap-4 py-4 md:gap-6 md:py-6">
              <div className="px-4 lg:px-6">
                <div className="flex justify-start">
                  <Filter
                    date={date}
                    stores={storesWithCount}
                    onFilterChange={(newFilter) => {
                      setDateFilter(newFilter);
                      setDate(newFilter.date);
                    }}
                    selectedStore={selectedStore}
                    setSelectedStore={
                      loginType === "shop" ? () => {} : setSelectedStore
                    }
                    hiddenStoreFilter={loginType === "shop"}
                  />
                </div>
              </div>
              <SectionCards data={timeFilteredData} />
              <div className="px-4 lg:px-6">
                <ChartAreaInteractive data={aggregatedData} />
              </div>
              <div className="px-4 lg:px-6">
                <ChartByNation data={timeFilteredData} />
              </div>
              <div>
                <DataTable data={sortedData} dateFilter={dateFilter} />
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </>
  );
}
