"use client";

import RefundDetailClient from "./refund-details";

import { SiteHeaderDetail } from "@/components/site-header-detail";
import axiosInstance from "@/lib/axios";
import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { appSessionStorage } from "@/lib/app-storage";
import { Spinner } from "@/components/ui/spinner";
import { toast } from "sonner";
import { useTranslations } from "next-intl";

export default function RefundDetailPage() {
  const params = useParams<{ id: string }>();
  const t = useTranslations("refundDetail");
  const [refund, setRefund] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const getOrderDetail = async (id: string) => {
    // ログアウト中はAPI呼び出しをスキップ
    if (appSessionStorage.getItem("isLoggingOut")) {
      return;
    }
    try {
      setLoading(true);
      const response = await axiosInstance.get(
        `/refundlist/company-detail/${id}`,
      );
      setRefund(response.data);
    } catch (err: any) {
      console.error("Failed to fetch order detail:", err);
      if (err.response?.status === 404) {
        toast.warning(t("page.fetchNotFound"));
      } else if (err.response?.status === 401) {
        toast.error(t("page.authError"));
      } else {
        toast.error(t("page.fetchFailed"));
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (params.id) {
      getOrderDetail(params.id);
    }
  }, [params.id]);
  return (
    <>
      <SiteHeaderDetail id={params.id || t("page.loadingId")} />
      <div className="flex flex-1 flex-col">
          {loading ? (
            <div className="flex items-center justify-center p-8">
              <Spinner className="h-8 w-8" />
              <p className="ml-2">{t("page.loading")}</p>
            </div>
          ) : refund?.refund ? (
            <RefundDetailClient refund={refund.refund}

            // 取消後に最新データを再取得するためのコールバック
            onRefresh= {()=> getOrderDetail(params.id)}
            />
          ) : (
            <div className="flex items-center justify-center p-8">
              <p className="animate-bounce">⚠️ {t("page.dataNotFound")}</p>
            </div>
          )}
      </div>
    </>
  );
}
