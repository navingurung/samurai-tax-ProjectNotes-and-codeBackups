"use client";

import { useState, useEffect, useRef } from "react";
import { useRouter,useSearchParams } from "next/navigation";
import { toast } from "sonner";
import {
  Card,
  CardHeader,
  CardDescription,
  CardContent,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import squareLogoBlack from "@/public/Square_Logo_2025_Black.png";
import squareLogoWhite from "@/public/Square_Logo_2025_White.png";
import { Button } from "@/components/ui/button";
import { Loader2, ShieldCheck, Unlink, AlertCircle } from "lucide-react";
import Image from "next/image";
import { useTranslations } from "next-intl";
import { SiteHeader } from "@/components/site-header";
import { getSquareOAuthUrl, revokeSquareOAuth } from "@/lib/square-api";
import { getCompanyDetails } from "../../account/actions/get-company-details";
import { useIsShopifyEmbedded } from "@/hooks/use-shopify-embedded";

// ── Constants ─────────────────────────────────────────────────────────────
const posName = "Square";
// ── Custom toast for error messages ─────────────────────────────────────
const showErrorToast = (message: string) => {
  toast.custom(
    (_toast) => (
      <div className="relative flex items-center gap-3 bg-red-500 border border-white rounded-lg px-4 py-3 shadow-lg">
        <AlertCircle className="h-5 w-5 text-white shrink-0 animate-pulse" />
        <p className="text-sm font-semibold text-white pr-4">{message}</p>
      </div>
    ),
    { position: "top-right", duration: 5000 },
  );
};


const getCompanyId = (): number | null => {
  if (typeof window === "undefined") return null;
  try {
    const auth = sessionStorage.getItem("authCompany");
    if (!auth) return null;
    const parsed = JSON.parse(auth);
    return parsed.company_id ?? null;
  } catch {
    return null;
  }
};

const getCompanyName = (): string | null => {
  if (typeof window === "undefined") return null;
  try {
    const auth = sessionStorage.getItem("authCompany");
    if (!auth) return null;
    const parsed = JSON.parse(auth);
    return parsed.name ?? null;
  } catch {
    return null;
  }
};

const formatDate = (dateStr: string | null | undefined): string => {
  if (!dateStr) return "-";
  return new Date(dateStr).toLocaleString("ja-JP", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
};

const Page = () => {
  const [merchantId, setMerchantId] = useState<string | null>(null);
  const [connectedAt, setConnectedAt] = useState<string | null>(null);
  const [companyName] = useState<string | null>(() => getCompanyName());
  const [isFetching, setIsFetching] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [isRevoking, setIsRevoking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const t = useTranslations("pos");

  const isConnected = !!merchantId;

  const hasFetched = useRef(false);

  const searchParams = useSearchParams();

  // ── Read URL error once and persist to sessionStorage ──
  useEffect(() => {
    const urlError = searchParams.get("error");
    if (!urlError) return;

    // Prevent duplicate toasts (e.g. React strict-mode double effects)
    const shownKey = `squareErrorShown:${urlError}`;
    if (sessionStorage.getItem(shownKey)) return;
    sessionStorage.setItem(shownKey, "1");

    if (urlError === "access_denied") {
      showErrorToast(t("errorCancelled", { posName }));
    } else if (urlError === "merchant_already_connected") {
      showErrorToast(t("errorMerchantAlreadyConnected", { posName }));
    }
  }, [searchParams, t]);

  // ── Fetch connection status once on mount ──
  useEffect(() => {
    if (hasFetched.current) return;
    hasFetched.current = true;

    const fetchStatus = async () => {
      try {
        const company_id = getCompanyId();
        if (!company_id) return;
        const data = await getCompanyDetails(company_id);
        setMerchantId(data.square_merchant_id ?? null);
        setConnectedAt(data.square_connected_at ?? null);
      } catch (error: any) {
        if (
          error?.response?.status === 400 ||
          error?.response?.status === 404
        ) {
          setMerchantId(null);
          setConnectedAt(null);
        } else {
          console.error("Error fetching Square status:", error);
        }
      } finally {
        setIsFetching(false);
      }
    };

    fetchStatus();
  }, []);

  const handleConnect = async () => {
    try {
      setIsLoading(true);
      setError(null);
      const company_id = getCompanyId();
      if (!company_id) throw new Error("Company not found");
      const data = await getSquareOAuthUrl(company_id);
      window.location.href = data.auth_url;
    } catch {
      const message = t("errorConnect", { posName });
      setError(message);
      showErrorToast(message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRevoke = async () => {
    try {
      setIsRevoking(true);
      setError(null);
      const company_id = getCompanyId();
      if (!company_id) throw new Error("Company not found");
      await revokeSquareOAuth(company_id);
      setMerchantId(null);
      setConnectedAt(null);
    } catch {
      const message = t("errorDisconnect", { posName });
      setError(message);
      showErrorToast(message);
    } finally {
      setIsRevoking(false);
    }
  };

  return (
    <>
      <SiteHeader title="Square" />
      <main className="flex flex-col min-h-4/5 bg-muted/30 p-6 gap-4">
        {isFetching ? (
          <div className="flex justify-center py-12">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : isConnected ? (
          // ── Connected state — flat row ──────────────────────────────────────
          <div className="rounded-xl border bg-background px-6 py-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-sm">
            <div className="flex items-center gap-4">
              <Image
                width={80}
                height={22}
                src={squareLogoBlack.src}
                alt="Square Logo"
                className="dark:hidden h-8 w-auto shrink-0"
              />
              <Image
                width={80}
                height={22}
                src={squareLogoWhite.src}
                alt="Square Logo"
                className="hidden dark:block h-8 w-auto shrink-0"
              />
              <div className="flex flex-col">
                {companyName && (
                  <span className="text-sm md:text-xl font-bold text-foreground">
                    {companyName}
                  </span>
                )}
                {connectedAt && (
                  <span className="text-xs md:text-sm text-muted-foreground">
                    {t("connectedAt", { date: formatDate(connectedAt) })}
                  </span>
                )}
              </div>
            </div>

            {/* Disconnect button with confirmation dialog */}
            <Dialog>
              <DialogTrigger asChild>
                <Button
                  variant="destructive"
                  disabled={isRevoking}
                  className="w-full text-md font-semibold sm:w-auto hover:opacity-90 transition-opacity cursor-pointer"
                >
                  {isRevoking ? (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  ) : (
                    <Unlink className="mr-2 h-4 w-4" />
                  )}
                  {t("disconnect")}
                </Button>
              </DialogTrigger>
              <DialogContent className="p-0 gap-0 overflow-hidden rounded-xl">
                <DialogHeader className="p-6 pb-4">
                  <DialogTitle className="text-center text-lg md:text-xl font-bold">
                    {t("disconnectTitle", { posName })}
                  </DialogTitle>
                  <DialogDescription className="text-center text-xs md:text-sm text-muted-foreground mt-1">
                    {t("disconnectDescription", { posName })}
                  </DialogDescription>
                </DialogHeader>
                <DialogFooter className="flex flex-row gap-0 border-t p-0 m-0">
                  <DialogTrigger asChild>
                    <Button
                      variant="ghost"
                      className="flex-1 rounded-none rounded-bl-xl h-12 font-bold text-base border-l cursor-pointer"
                    >
                      {t("disconnectCancel")}
                    </Button>
                  </DialogTrigger>
                  <Button
                    variant="destructive"
                    className="flex-1 rounded-none rounded-br-xl h-12 font-bold text-base cursor-pointer"
                    onClick={handleRevoke}
                    disabled={isRevoking}
                  >
                    {isRevoking ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        {t("disconnecting")}
                      </>
                    ) : (
                      t("disconnectConfirm")
                    )}
                  </Button>
                  </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        ) : (
          // ── Disconnected state — centered card ──────────────────────────────
          <div className="flex flex-1 items-center justify-center">
            <Card className="max-w-md rounded-xl border-2 border-gray-100 bg-background px-1 py-6 shadow-sm sm:px-4 sm:py-12">
              <CardHeader className="space-y-2 text-center">
                <div className="flex items-center justify-center">
                  <Image
                    width={300}
                    height={48}
                    src={squareLogoBlack.src}
                    alt="Square Logo"
                    className="dark:hidden mx-auto h-10 w-auto shrink-0"
                  />
                  <Image
                    width={300}
                    height={48}
                    src={squareLogoWhite.src}
                    alt="Square Logo"
                    className="hidden dark:block mx-auto h-10 w-auto shrink-0"
                  />
                </div>
                <div className="space-y-2">
                  <CardDescription className="text-sm leading-6 mx-auto text-muted-foreground">
                    {t.rich("connectDescription", {
                      posName,
                      bold: (chunks) => (
                        <span className="font-bold">{chunks}</span>
                      ),
                    })}
                  </CardDescription>
                </div>
              </CardHeader>

              <CardContent className="space-y-3">
                <Button
                  className="w-full h-12 rounded-md text-lg font-bold bg-[#0054A7] hover:bg-[#0054A7]/90 dark:text-white cursor-pointer transition-colors"
                  disabled={isLoading}
                  onClick={handleConnect}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      {t("connecting")}
                    </>
                  ) : (
                    (t("connectButton", { posName }) as string)
                  )}
                </Button>

                {error ? (
                  <p className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive">
                    {error}
                  </p>
                ) : null}

                <div className="flex items-start gap-2 rounded-xl bg-muted/60 p-3 text-sm text-muted-foreground">
                  <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0" />
                  <p className="text-justify">
                    {t.rich("oauthNote", {
                      posName,
                      bold: (chunks) => (
                        <span className="font-bold">{chunks}</span>
                      ),
                    })}
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Global error — shown outside card when in connected state */}
        {error && isConnected ? (
          <p className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive">
            {error}
          </p>
        ) : null}
      </main>
    </>
  );
};

// Shopify管理画面内では他社POS（Square）の連携ページを表示しない（App Store ルール 1.1.8）
const SquarePage = () => {
  const router = useRouter();
  const isEmbedded = useIsShopifyEmbedded();

  useEffect(() => {
    if (isEmbedded) router.replace("/dashboard");
  }, [isEmbedded, router]);

  if (isEmbedded) return null;
  return <Page />;
};

export default SquarePage;
