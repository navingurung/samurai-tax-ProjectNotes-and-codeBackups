"""Shopify staff links (SAM-610).

A link says "Shopify staff `shopify_user_id` in store `shopify_store_id` is
logged in as company `company_id` (and shop `shop_id`, or None for a company
login)". It replaces the login cookie inside the Shopify admin iframe.

Temporary JSON-file store. The `shopify_staff_links` table replaces it later
(SAM-608 Approach), so callers must only use get_link / save_link / delete_links.
"""

import json
import os
import tempfile
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

LINKS_PATH = Path(__file__).resolve().parents[2] / "shopify_staff_links.json"

_lock = threading.Lock()


def _key(shopify_store_id: int, shopify_user_id: int) -> str:
    return f"{shopify_store_id}:{shopify_user_id}"


def _load() -> dict[str, dict]:
    try:
        with open(LINKS_PATH, encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError:
        return {}
    except json.JSONDecodeError:
        if LINKS_PATH.stat().st_size == 0:
            return {}
        raise
    return data if isinstance(data, dict) else {}


def _save(links: dict[str, dict]) -> None:
    # Write to a temp file in the same directory, then atomically replace,
    # so a crash never leaves a half-written file.
    LINKS_PATH.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(dir=LINKS_PATH.parent, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(links, f, ensure_ascii=False, indent=2)
        os.replace(tmp_path, LINKS_PATH)
    except BaseException:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)
        raise


def get_link(shopify_store_id: int, shopify_user_id: int) -> Optional[dict]:
    with _lock:
        return _load().get(_key(shopify_store_id, shopify_user_id))


def save_link(
    shopify_store_id: int,
    shopify_user_id: int,
    company_id: int,
    shop_id: Optional[int],
) -> dict:
    """Create the link, or overwrite it when the same staff logs in again."""
    link = {
        "shopify_store_id": shopify_store_id,
        "shopify_user_id": shopify_user_id,
        "company_id": company_id,
        "shop_id": shop_id,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    with _lock:
        links = _load()
        links[_key(shopify_store_id, shopify_user_id)] = link
        _save(links)
    return link


def delete_links(
    *,
    shopify_store_id: Optional[int] = None,
    shopify_user_id: Optional[int] = None,
    company_id: Optional[int] = None,
    shop_id: Optional[int] = None,
) -> int:
    """Delete every link matching ALL given filters. Returns the count.

    logout: store + user / uninstall, shop/redact: store /
    password change, deactivation: company or shop.
    """
    filters = {
        k: v
        for k, v in {
            "shopify_store_id": shopify_store_id,
            "shopify_user_id": shopify_user_id,
            "company_id": company_id,
            "shop_id": shop_id,
        }.items()
        if v is not None
    }
    if not filters:
        raise ValueError("delete_links requires at least one filter")

    with _lock:
        links = _load()
        kept = {
            k: link
            for k, link in links.items()
            if not all(link.get(f) == v for f, v in filters.items())
        }
        deleted = len(links) - len(kept)
        if deleted:
            _save(kept)
    return deleted
