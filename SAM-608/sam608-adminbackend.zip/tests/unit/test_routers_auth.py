"""SAM-610 / SAM-611 — the dashboard inside the Shopify admin.

With `Authorization: Bearer <Shopify session token>`:
- SAM-610: the company/shop login endpoints save a staff link instead of
  setting cookies, and logout deletes it.
- SAM-611: dashboard APIs identify the caller from the token + staff link,
  rechecked on every request, and ignore cookies.
Without the header, everything behaves exactly as before.

Real ASGI endpoints (TestClient) with in-memory SQLite and real session-token
JWTs signed with a test secret.
"""

import asyncio
from datetime import datetime, timedelta, timezone

import pytest
from fastapi.testclient import TestClient
from jose import jwt as jose_jwt
from sqlalchemy.pool import StaticPool
from sqlmodel import Session, SQLModel, create_engine

from AdminApp.database import get_session
from AdminApp.main import app
from AdminApp.models import Company, Shop, ShopifyStore
from AdminApp.routers import auth, shopify
from AdminApp.routers.auth import bcrypt_context
from AdminApp.utils import shopify_staff_links
from AdminApp.utils.encrypt import encrypt

SHOP_PW = "shop-pass"
COMPANY_PW = "company-pass"

SHOPIFY_SECRET = "test-shopify-secret"
SHOPIFY_CLIENT_ID = "test-shopify-client-id"
LINKED_SHOP = "linked-store.myshopify.com"
UNLINKED_SHOP = "unlinked-store.myshopify.com"
OTHER_COMPANY_SHOP = "other-company-store.myshopify.com"


def _company(pk):
    return Company(
        id=pk,
        biz_name=f"Comp{pk}",
        biz_name_kana="カンパニー",
        biz_place="Tokyo",
        biz_place_kana="トウキョウ",
        manager_name="Taro",
        manager_name_kana="タロウ",
        manager_email=encrypt(f"manager{pk}@example.com"),
        manager_phone=encrypt("0300000000"),
        sender_id=1,
        login_id=f"company{pk}",
        login_password=bcrypt_context.hash(COMPANY_PW),
    )


def _shop(pk, company_id, shopify_store_id=None):
    return Shop(
        id=pk,
        login_id=f"shop{pk}",
        login_password=bcrypt_context.hash(SHOP_PW),
        shop_id=f"S{pk}",
        shop_name=f"Shop{pk}",
        shop_name_kana="ショップ",
        shop_place="Tokyo",
        shop_place_kana="トウキョウ",
        shopify_location_id="loc",
        contact_name="Taro",
        contact_name_kana="タロウ",
        contact_email="taro@example.com",
        contact_phone="0300000000",
        company_id=company_id,
        shopify_store_id=shopify_store_id,
    )


@pytest.fixture
def client():
    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    SQLModel.metadata.create_all(engine)
    with Session(engine) as s:
        s.add(_company(1))
        s.add(_company(2))
        s.add(ShopifyStore(id=1, company_id=1, shopify_shop_domain=LINKED_SHOP))
        s.add(ShopifyStore(id=2, company_id=None, shopify_shop_domain=UNLINKED_SHOP))
        s.add(ShopifyStore(id=3, company_id=2, shopify_shop_domain=OTHER_COMPANY_SHOP))
        s.add(_shop(1, company_id=1, shopify_store_id=1))  # connected to store 1
        s.add(_shop(2, company_id=1))  # same company, not connected to any store
        s.commit()

    def _override():
        with Session(engine) as session:
            yield session

    app.dependency_overrides[get_session] = _override
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()


@pytest.fixture(autouse=True)
def links_path(tmp_path, monkeypatch):
    path = tmp_path / "shopify_staff_links.json"
    monkeypatch.setattr(shopify_staff_links, "LINKS_PATH", path)
    monkeypatch.setattr(shopify, "SHOPIFY_CLIENT_SECRET", SHOPIFY_SECRET)
    monkeypatch.setattr(shopify, "SHOPIFY_CLIENT_ID", SHOPIFY_CLIENT_ID)
    return path


def _bearer(shop_domain=LINKED_SHOP, sub="111", secret=SHOPIFY_SECRET):
    now = datetime.now(timezone.utc)
    token = jose_jwt.encode(
        {
            "iss": f"https://{shop_domain}/admin",
            "dest": f"https://{shop_domain}",
            "aud": SHOPIFY_CLIENT_ID,
            "sub": sub,
            "exp": now + timedelta(minutes=1),
            "nbf": now - timedelta(seconds=5),
        },
        secret,
        algorithm="HS256",
    )
    return {"Authorization": f"Bearer {token}"}


def _login(client, path, username, password, headers=None):
    return client.post(
        path, data={"username": username, "password": password}, headers=headers
    )


# ═══════════════════════════════════════════════════════════════════════════
# SAM-610 — login/logout with Bearer
# ═══════════════════════════════════════════════════════════════════════════

# ─── Login with Bearer ──────────────────────────────────────────────────────


def test_company_login_saves_link_without_cookie(client):
    r = _login(client, "/auth/company-token", "company1", COMPANY_PW, _bearer())

    assert r.status_code == 200
    assert r.json()["company_id"] == 1
    assert "cat" not in client.cookies
    link = shopify_staff_links.get_link(1, 111)
    assert link is not None
    assert link["company_id"] == 1
    assert link["shop_id"] is None


def test_shop_login_saves_link_without_cookie(client):
    r = _login(client, "/auth/shop-token", "shop1", SHOP_PW, _bearer())

    assert r.status_code == 200
    assert r.json()["shop_id"] == 1
    assert "sat" not in client.cookies
    link = shopify_staff_links.get_link(1, 111)
    assert link is not None
    assert link["company_id"] == 1
    assert link["shop_id"] == 1


def test_login_again_replaces_link(client):
    _login(client, "/auth/company-token", "company1", COMPANY_PW, _bearer())
    _login(client, "/auth/shop-token", "shop1", SHOP_PW, _bearer())

    link = shopify_staff_links.get_link(1, 111)
    assert link is not None
    assert link["shop_id"] == 1


# ─── Login rejections ───────────────────────────────────────────────────────


def test_wrong_password_401(client):
    r = _login(client, "/auth/company-token", "company1", "wrong", _bearer())

    assert r.status_code == 401
    assert shopify_staff_links.get_link(1, 111) is None


def test_invalid_token_401(client):
    headers = _bearer(secret="other-secret")
    r = _login(client, "/auth/company-token", "company1", COMPANY_PW, headers)

    assert r.status_code == 401
    assert shopify_staff_links.get_link(1, 111) is None


def test_unlinked_store_403(client):
    headers = _bearer(shop_domain=UNLINKED_SHOP)
    r = _login(client, "/auth/company-token", "company1", COMPANY_PW, headers)

    assert r.status_code == 403
    assert shopify_staff_links.get_link(2, 111) is None


def test_company_login_store_of_other_company_403(client):
    headers = _bearer(shop_domain=OTHER_COMPANY_SHOP)
    r = _login(client, "/auth/company-token", "company1", COMPANY_PW, headers)

    assert r.status_code == 403
    assert shopify_staff_links.get_link(3, 111) is None


def test_shop_login_shop_not_in_store_403(client):
    r = _login(client, "/auth/shop-token", "shop2", SHOP_PW, _bearer())

    assert r.status_code == 403
    assert shopify_staff_links.get_link(1, 111) is None


# ─── Logout with Bearer ─────────────────────────────────────────────────────


def test_logout_deletes_only_own_link(client):
    _login(client, "/auth/company-token", "company1", COMPANY_PW, _bearer(sub="111"))
    _login(client, "/auth/shop-token", "shop1", SHOP_PW, _bearer(sub="222"))

    r = client.post("/auth/company-logout", headers=_bearer(sub="111"))

    assert r.status_code == 200
    assert shopify_staff_links.get_link(1, 111) is None
    assert shopify_staff_links.get_link(1, 222) is not None

    r = client.post("/auth/shop-logout", headers=_bearer(sub="222"))

    assert r.status_code == 200
    assert shopify_staff_links.get_link(1, 222) is None


def test_logout_invalid_token_401(client):
    r = client.post("/auth/company-logout", headers=_bearer(secret="other-secret"))

    assert r.status_code == 401


# ─── Without Bearer: unchanged ──────────────────────────────────────────────


def test_company_login_without_bearer_sets_cookie_no_link(client, links_path):
    r = _login(client, "/auth/company-token", "company1", COMPANY_PW)

    assert r.status_code == 200
    assert "cat" in client.cookies
    assert not links_path.exists()


def test_shop_login_without_bearer_sets_cookie_no_link(client, links_path):
    r = _login(client, "/auth/shop-token", "shop1", SHOP_PW)

    assert r.status_code == 200
    assert "sat" in client.cookies
    assert not links_path.exists()


# ═══════════════════════════════════════════════════════════════════════════
# SAM-611 — dashboard APIs inside the Shopify admin (Bearer + staff link)
# ═══════════════════════════════════════════════════════════════════════════


def test_company_link_reaches_company_api(client):
    _login(client, "/auth/company-token", "company1", COMPANY_PW, _bearer())

    r = client.get("/auth/company-whoami", headers=_bearer())

    assert r.status_code == 200
    assert r.json()["company_id"] == 1
    assert r.json()["email"] == "manager1@example.com"


def test_shop_link_reaches_shop_api(client):
    _login(client, "/auth/shop-token", "shop1", SHOP_PW, _bearer())

    r = client.get("/auth/shop-whoami", headers=_bearer())

    assert r.status_code == 200
    assert r.json()["shop_id"] == 1


def test_company_link_rejected_on_shop_api(client):
    _login(client, "/auth/company-token", "company1", COMPANY_PW, _bearer())

    assert client.get("/auth/shop-whoami", headers=_bearer()).status_code == 401


def test_shop_link_rejected_on_company_api(client):
    _login(client, "/auth/shop-token", "shop1", SHOP_PW, _bearer())

    assert client.get("/auth/company-whoami", headers=_bearer()).status_code == 401


def test_no_link_401(client):
    # Another staff member of the same store, never logged in.
    assert (
        client.get("/auth/company-whoami", headers=_bearer(sub="999")).status_code
        == 401
    )


def test_invalid_token_on_api_401(client):
    _login(client, "/auth/company-token", "company1", COMPANY_PW, _bearer())

    headers = _bearer(secret="other-secret")
    assert client.get("/auth/company-whoami", headers=headers).status_code == 401


def test_link_company_no_longer_owns_store_401(client):
    # Store 1 now belongs to company 1, but the link points at company 2.
    shopify_staff_links.save_link(1, 111, company_id=2, shop_id=None)

    assert client.get("/auth/company-whoami", headers=_bearer()).status_code == 401


def test_link_shop_no_longer_in_store_401(client):
    # shop2 is not connected to store 1.
    shopify_staff_links.save_link(1, 111, company_id=1, shop_id=2)

    assert client.get("/auth/shop-whoami", headers=_bearer()).status_code == 401


def test_bearer_wins_over_cookie(client):
    _login(client, "/auth/shop-token", "shop1", SHOP_PW)  # sets the `sat` cookie
    _login(client, "/auth/company-token", "company1", COMPANY_PW, _bearer())

    r = client.get("/auth/company-whoami", headers=_bearer())

    assert r.status_code == 200
    assert r.json()["company_id"] == 1


def test_bearer_without_link_does_not_fall_back_to_cookie(client):
    _login(client, "/auth/company-token", "company1", COMPANY_PW)  # sets `cat`

    assert client.get("/auth/company-whoami", headers=_bearer()).status_code == 401


def test_cookie_without_bearer_unchanged(client):
    _login(client, "/auth/company-token", "company1", COMPANY_PW)

    r = client.get("/auth/company-whoami")

    assert r.status_code == 200
    assert r.json()["company_id"] == 1


def test_admin_api_ignores_bearer(client):
    _login(client, "/auth/company-token", "company1", COMPANY_PW, _bearer())

    assert client.get("/auth/whoami", headers=_bearer()).status_code == 401


@pytest.mark.parametrize(
    "dependency",
    [
        auth.get_current_company_or_shop_from_cookie,
        auth.get_dashboard_or_admin_from_cookie,
        auth.get_current_user_or_company_or_shop_from_cookie,
    ],
)
def test_combined_dependencies_return_shopify_identity(dependency):
    identity = {"type": "shop", "login_id": "shop1", "shop_id": 1, "name": "Shop1"}

    assert asyncio.run(dependency(shopify=identity)) == identity
