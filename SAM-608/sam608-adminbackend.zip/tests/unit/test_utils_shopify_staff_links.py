import json

import pytest

from AdminApp.utils import shopify_staff_links as links


@pytest.fixture(autouse=True)
def links_path(tmp_path, monkeypatch):
    path = tmp_path / "shopify_staff_links.json"
    monkeypatch.setattr(links, "LINKS_PATH", path)
    return path


def test_get_link_returns_none_when_file_missing():
    assert links.get_link(1, 100) is None


def test_get_link_returns_none_when_file_empty(links_path):
    links_path.write_text("")
    assert links.get_link(1, 100) is None


def test_save_and_get_company_link():
    links.save_link(1, 100, company_id=5, shop_id=None)

    link = links.get_link(1, 100)
    assert link is not None
    assert link["company_id"] == 5
    assert link["shop_id"] is None
    assert link["created_at"]


def test_save_and_get_shop_link():
    links.save_link(1, 100, company_id=5, shop_id=31)

    link = links.get_link(1, 100)
    assert link is not None
    assert link["shop_id"] == 31


def test_links_are_per_store_and_per_staff():
    links.save_link(1, 100, company_id=5, shop_id=None)

    assert links.get_link(1, 200) is None
    assert links.get_link(2, 100) is None


def test_save_overwrites_same_staff(links_path):
    links.save_link(1, 100, company_id=5, shop_id=None)
    links.save_link(1, 100, company_id=5, shop_id=31)

    link = links.get_link(1, 100)
    assert link is not None
    assert link["shop_id"] == 31
    assert len(json.loads(links_path.read_text())) == 1


def _seed():
    links.save_link(1, 100, company_id=5, shop_id=None)
    links.save_link(1, 200, company_id=5, shop_id=31)
    links.save_link(2, 100, company_id=6, shop_id=40)


def test_delete_by_store_and_user():
    _seed()

    assert links.delete_links(shopify_store_id=1, shopify_user_id=100) == 1
    assert links.get_link(1, 100) is None
    assert links.get_link(1, 200) is not None
    assert links.get_link(2, 100) is not None


def test_delete_by_store():
    _seed()

    assert links.delete_links(shopify_store_id=1) == 2
    assert links.get_link(2, 100) is not None


def test_delete_by_company():
    _seed()

    assert links.delete_links(company_id=5) == 2
    assert links.get_link(2, 100) is not None


def test_delete_by_shop():
    _seed()

    assert links.delete_links(shop_id=31) == 1
    assert links.get_link(1, 200) is None
    assert links.get_link(1, 100) is not None


def test_delete_no_match_returns_zero():
    _seed()

    assert links.delete_links(shopify_store_id=99) == 0


def test_delete_requires_a_filter():
    with pytest.raises(ValueError):
        links.delete_links()


def test_no_temp_files_left(links_path):
    links.save_link(1, 100, company_id=5, shop_id=None)
    links.delete_links(shopify_store_id=1)

    assert [p.name for p in links_path.parent.iterdir()] == [links_path.name]
