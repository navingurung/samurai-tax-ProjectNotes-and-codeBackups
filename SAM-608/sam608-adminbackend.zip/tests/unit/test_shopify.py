import asyncio
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from fastapi import HTTPException
from jose import jwt as jose_jwt

from AdminApp.routers import shopify
from AdminApp.routers.shopify import (
    ShopifyAPIError,
    ExchangeTokenRequest,
    LinkShopifyStoreRequest,
    UnlinkShopifyStoreRequest,
    verify_app_load_hmac,
    verify_webhook_hmac,
    verify_session_token,
    extract_shop_domain,
    verify_embedded_session_token,
    exchange_session_token,
    refresh_access_token,
    ensure_valid_shopify_token,
    shopify_graphql,
    shopify_app,
    exchange,
    link_shopify_store,
    unlink_shopify_store,
    get_available_to_connect_stores,
    get_store_by_company,
    app_uninstalled,
    compliance_webhook,
    get_locations_by_company,
    connect_shop_shopify,
    disconnect_shop_shopify,
    TOKEN_REFRESH_BUFFER_SECONDS,
)
from AdminApp.utils import shopify_staff_links
from AdminApp.utils.encrypt import encrypt

# ─── Test constants ─────────────────────────────────────────────────────────
# A fixed secret so HMAC/JWT tests are deterministic. Patched onto the
# module in place of the real os.getenv-sourced value for every test that
# needs it, matching how square.py's tests never touch real credentials.
_TEST_SECRET = "test-client-secret"
_TEST_CLIENT_ID = "test-client-id"


@pytest.fixture(autouse=True)
def _staff_links_path(tmp_path, monkeypatch):
    # Never touch the real shopify_staff_links.json from tests.
    path = tmp_path / "shopify_staff_links.json"
    monkeypatch.setattr(shopify_staff_links, "LINKS_PATH", path)
    return path


# ─── Model mocks ────────────────────────────────────────────────────────────


def _mock_store(**overrides):
    defaults = dict(
        id=1,
        company_id=None,
        shopify_shop_domain="test-store.myshopify.com",
        shopify_access_token_encrypted=None,
        shopify_refresh_token_encrypted=None,
        scopes=None,
        access_token_expires_at=None,
        refresh_token_expires_at=None,
        connected_at=None,
        disconnected_at=None,
    )
    defaults.update(overrides)
    return SimpleNamespace(**defaults)


def _mock_store_connected(**overrides):
    defaults = dict(
        id=1,
        company_id=None,
        shopify_shop_domain="test-store.myshopify.com",
        shopify_access_token_encrypted=encrypt("valid-access-token"),
        shopify_refresh_token_encrypted=encrypt("valid-refresh-token"),
        scopes="read_locations,read_orders",
        access_token_expires_at=None,
        refresh_token_expires_at=None,
        connected_at=None,
        disconnected_at=None,
    )
    defaults.update(overrides)
    return SimpleNamespace(**defaults)


def _mock_shop(**overrides):
    defaults = dict(
        id=1,
        company_id=1,
        shopify_store_id=None,
        shopify_location_id_public=None,
        use_shopify_public=False,
    )
    defaults.update(overrides)
    return SimpleNamespace(**defaults)


def _mock_company(**overrides):
    defaults = dict(id=1)
    defaults.update(overrides)
    return SimpleNamespace(**defaults)


_ADMIN_USER = {"login_id": "admin", "user_id": 1, "name": "Admin", "role": "admin"}


# ─── Request mocks ──────────────────────────────────────────────────────────


def _mock_request(query_params=None, headers=None, body: bytes = b""):
    """
    Fakes a FastAPI Request for route-level tests. body() is async on the
    real Request object, so it must be an AsyncMock even though the route
    functions themselves may be sync (shopify_app, exchange) or async
    (app_uninstalled, compliance_webhook) — both call `await request.body()`
    or, for the sync GET route, only read query_params (never body).
    """
    request = MagicMock()
    request.query_params = query_params or {}
    request.headers = headers or {}
    request.body = AsyncMock(return_value=body)
    return request


def _run_async(coro):
    """Runs an async route function synchronously — no TestClient/anyio
    fixture wiring needed, matching this file's pure-unit style."""
    return asyncio.run(coro)


# ─── Helpers for computing real signatures in tests ─────────────────────────


def _compute_app_load_hmac(params: dict, secret: str) -> str:
    import hashlib
    import hmac as hmac_lib
    from urllib.parse import urlencode

    sorted_params = urlencode(sorted(params.items()))
    return hmac_lib.new(
        secret.encode(), sorted_params.encode(), hashlib.sha256
    ).hexdigest()


def _compute_webhook_hmac(body: bytes, secret: str) -> str:
    import base64
    import hashlib
    import hmac as hmac_lib

    digest = hmac_lib.new(secret.encode(), body, hashlib.sha256).digest()
    return base64.b64encode(digest).decode()


# ═══════════════════════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════════════════════

# ─── verify_app_load_hmac ───────────────────────────────────────────────────


def test_verify_app_load_hmac_valid():
    with patch.object(shopify, "SHOPIFY_CLIENT_SECRET", _TEST_SECRET):
        params = {"shop": "test-store.myshopify.com", "timestamp": "123"}
        valid_hmac = _compute_app_load_hmac(params, _TEST_SECRET)

        result = verify_app_load_hmac({**params, "hmac": valid_hmac})

    assert result is True


def test_verify_app_load_hmac_invalid():
    with patch.object(shopify, "SHOPIFY_CLIENT_SECRET", _TEST_SECRET):
        result = verify_app_load_hmac(
            {"shop": "test-store.myshopify.com", "hmac": "wrong-hmac"}
        )

    assert result is False


# ─── verify_webhook_hmac ────────────────────────────────────────────────────


def test_verify_webhook_hmac_valid():
    with patch.object(shopify, "SHOPIFY_CLIENT_SECRET", _TEST_SECRET):
        body = b'{"id": 123}'
        valid_hmac = _compute_webhook_hmac(body, _TEST_SECRET)

        result = verify_webhook_hmac(body, valid_hmac)

    assert result is True


def test_verify_webhook_hmac_missing_header():
    result = verify_webhook_hmac(b'{"id": 123}', "")

    assert result is False


def test_verify_webhook_hmac_invalid():
    with patch.object(shopify, "SHOPIFY_CLIENT_SECRET", _TEST_SECRET):
        result = verify_webhook_hmac(b'{"id": 123}', "wrong-signature")

    assert result is False


# ─── verify_session_token ───────────────────────────────────────────────────
# Real JWTs, not mocked — this is the one piece of logic that must actually
# decode correctly, since a mock here would never catch a real algorithm/
# audience mismatch.


def test_verify_session_token_valid():
    with patch.object(shopify, "SHOPIFY_CLIENT_SECRET", _TEST_SECRET), patch.object(
        shopify, "SHOPIFY_CLIENT_ID", _TEST_CLIENT_ID
    ):
        token = jose_jwt.encode(
            {"dest": "https://test-store.myshopify.com", "aud": _TEST_CLIENT_ID},
            _TEST_SECRET,
            algorithm="HS256",
        )

        claims = verify_session_token(token)

    assert claims["dest"] == "https://test-store.myshopify.com"


def test_verify_session_token_wrong_secret_raises():
    with patch.object(shopify, "SHOPIFY_CLIENT_SECRET", _TEST_SECRET), patch.object(
        shopify, "SHOPIFY_CLIENT_ID", _TEST_CLIENT_ID
    ):
        token = jose_jwt.encode(
            {"dest": "https://test-store.myshopify.com", "aud": _TEST_CLIENT_ID},
            "some-other-secret",
            algorithm="HS256",
        )

        with pytest.raises(Exception):  # jose.exceptions.JWTError
            verify_session_token(token)


def test_verify_session_token_wrong_audience_raises():
    with patch.object(shopify, "SHOPIFY_CLIENT_SECRET", _TEST_SECRET), patch.object(
        shopify, "SHOPIFY_CLIENT_ID", _TEST_CLIENT_ID
    ):
        token = jose_jwt.encode(
            {"dest": "https://test-store.myshopify.com", "aud": "some-other-client"},
            _TEST_SECRET,
            algorithm="HS256",
        )

        with pytest.raises(Exception):
            verify_session_token(token)


# ─── extract_shop_domain ────────────────────────────────────────────────────


def test_extract_shop_domain_from_dest():
    claims = {"dest": "https://test-store.myshopify.com/admin"}

    assert extract_shop_domain(claims) == "test-store.myshopify.com"


def test_extract_shop_domain_from_iss_when_dest_missing():
    claims = {"iss": "https://test-store.myshopify.com/admin/oauth"}

    assert extract_shop_domain(claims) == "test-store.myshopify.com"


def test_extract_shop_domain_rejects_non_myshopify_domain():
    claims = {"dest": "https://evil.example.com"}

    assert extract_shop_domain(claims) is None


def test_extract_shop_domain_no_matching_claims():
    claims = {"sub": "someone"}

    assert extract_shop_domain(claims) is None


# ─── verify_embedded_session_token ──────────────────────────────────────────


def _session_token(secret=_TEST_SECRET, **overrides):
    now = datetime.now(timezone.utc)
    claims = {
        "iss": "https://test-store.myshopify.com/admin",
        "dest": "https://test-store.myshopify.com",
        "aud": _TEST_CLIENT_ID,
        "sub": "123456789",
        "exp": now + timedelta(minutes=1),
        "nbf": now - timedelta(seconds=5),
    }
    claims.update(overrides)
    claims = {k: v for k, v in claims.items() if v is not None}
    return jose_jwt.encode(claims, secret, algorithm="HS256")


def _verify_embedded(token):
    with patch.object(shopify, "SHOPIFY_CLIENT_SECRET", _TEST_SECRET), patch.object(
        shopify, "SHOPIFY_CLIENT_ID", _TEST_CLIENT_ID
    ):
        return verify_embedded_session_token(token)


def test_verify_embedded_session_token_valid():
    assert _verify_embedded(_session_token()) == ("test-store.myshopify.com", 123456789)


@pytest.mark.parametrize(
    "token",
    [
        pytest.param(
            lambda: _session_token(secret="some-other-secret"), id="wrong-secret"
        ),
        pytest.param(lambda: "not-a-jwt", id="garbage"),
        pytest.param(
            lambda: _session_token(
                exp=datetime.now(timezone.utc) - timedelta(minutes=5)
            ),
            id="expired",
        ),
        pytest.param(
            lambda: _session_token(
                nbf=datetime.now(timezone.utc) + timedelta(minutes=5)
            ),
            id="not-yet-valid",
        ),
        pytest.param(lambda: _session_token(aud="some-other-client"), id="wrong-aud"),
        pytest.param(
            lambda: _session_token(dest="https://other-store.myshopify.com"),
            id="iss-dest-mismatch",
        ),
        pytest.param(lambda: _session_token(dest=None), id="missing-dest"),
        pytest.param(
            lambda: _session_token(
                iss="https://evil.example.com/admin", dest="https://evil.example.com"
            ),
            id="non-myshopify",
        ),
        pytest.param(lambda: _session_token(sub=None), id="missing-sub"),
        pytest.param(lambda: _session_token(sub="abc"), id="non-numeric-sub"),
    ],
)
def test_verify_embedded_session_token_rejects(token):
    with pytest.raises(HTTPException) as exc_info:
        _verify_embedded(token())

    assert exc_info.value.status_code == 401
    assert exc_info.value.detail == "Invalid session token"


# ─── exchange_session_token ──────────────────────────────────────────────────


def test_exchange_session_token_success():
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.json.return_value = {"access_token": "tok123", "expires_in": 3600}

    with patch("AdminApp.routers.shopify.requests.post", return_value=mock_resp):
        data = exchange_session_token("test-store.myshopify.com", "session-tok")

    assert data["access_token"] == "tok123"


def test_exchange_session_token_http_error():
    mock_resp = MagicMock()
    mock_resp.status_code = 401
    mock_resp.json.return_value = {"error": "unauthorized"}

    with patch("AdminApp.routers.shopify.requests.post", return_value=mock_resp):
        with pytest.raises(ShopifyAPIError) as exc_info:
            exchange_session_token("test-store.myshopify.com", "bad-tok")

    assert exc_info.value.status_code == 401


def test_exchange_session_token_network_error():
    import requests as req

    with patch(
        "AdminApp.routers.shopify.requests.post",
        side_effect=req.RequestException("timeout"),
    ):
        with pytest.raises(ShopifyAPIError) as exc_info:
            exchange_session_token("test-store.myshopify.com", "session-tok")

    assert exc_info.value.status_code == 500


# ─── refresh_access_token ────────────────────────────────────────────────────


def test_refresh_access_token_success():
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.json.return_value = {"access_token": "new-tok", "expires_in": 3600}

    with patch("AdminApp.routers.shopify.requests.post", return_value=mock_resp):
        data = refresh_access_token("test-store.myshopify.com", "refresh-tok")

    assert data["access_token"] == "new-tok"


def test_refresh_access_token_http_error():
    mock_resp = MagicMock()
    mock_resp.status_code = 400
    mock_resp.json.return_value = {"error": "invalid_grant"}

    with patch("AdminApp.routers.shopify.requests.post", return_value=mock_resp):
        with pytest.raises(ShopifyAPIError) as exc_info:
            refresh_access_token("test-store.myshopify.com", "bad-refresh-tok")

    assert exc_info.value.status_code == 400


def test_refresh_access_token_network_error():
    import requests as req

    with patch(
        "AdminApp.routers.shopify.requests.post",
        side_effect=req.RequestException("timeout"),
    ):
        with pytest.raises(ShopifyAPIError) as exc_info:
            refresh_access_token("test-store.myshopify.com", "refresh-tok")

    assert exc_info.value.status_code == 500


# ─── ensure_valid_shopify_token ───────────────────────────────────────────────


def test_ensure_valid_shopify_token_not_connected_raises_400():
    store = _mock_store()  # no tokens
    session = MagicMock()

    with pytest.raises(HTTPException) as exc_info:
        ensure_valid_shopify_token(store, session)

    assert exc_info.value.status_code == 400


def test_ensure_valid_shopify_token_still_valid_returns_decrypted():
    future = datetime.now(timezone.utc).replace(tzinfo=None) + timedelta(
        seconds=TOKEN_REFRESH_BUFFER_SECONDS + 600
    )
    store = _mock_store_connected(access_token_expires_at=future)
    session = MagicMock()

    token = ensure_valid_shopify_token(store, session)

    assert token == "valid-access-token"
    session.add.assert_not_called()  # no refresh happened


def test_ensure_valid_shopify_token_expired_refreshes_and_returns():
    past = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(hours=1)
    store = _mock_store_connected(access_token_expires_at=past)
    session = MagicMock()

    with patch.object(
        shopify,
        "refresh_access_token",
        return_value={
            "access_token": "new-access-token",
            "refresh_token": "new-refresh-token",
            "expires_in": 3600,
        },
    ):
        token = ensure_valid_shopify_token(store, session)

    assert token == "new-access-token"
    session.add.assert_called_once()
    session.commit.assert_called_once()


def test_ensure_valid_shopify_token_refresh_fails_raises_http():
    past = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(hours=1)
    store = _mock_store_connected(access_token_expires_at=past)
    session = MagicMock()

    with patch.object(
        shopify,
        "refresh_access_token",
        side_effect=ShopifyAPIError(401, {"error": "unauthorized"}),
    ):
        with pytest.raises(HTTPException) as exc_info:
            ensure_valid_shopify_token(store, session)

    assert exc_info.value.status_code == 401


def test_ensure_valid_shopify_token_no_access_token_in_refresh_response():
    past = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(hours=1)
    store = _mock_store_connected(access_token_expires_at=past)
    session = MagicMock()

    with patch.object(
        shopify, "refresh_access_token", return_value={"expires_in": 3600}
    ):
        with pytest.raises(HTTPException) as exc_info:
            ensure_valid_shopify_token(store, session)

    assert exc_info.value.status_code == 400


# ─── shopify_graphql ─────────────────────────────────────────────────────────


def test_shopify_graphql_success():
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.json.return_value = {"data": {"locations": {"edges": []}}}

    with patch("AdminApp.routers.shopify.requests.post", return_value=mock_resp):
        data = shopify_graphql("test-store.myshopify.com", "tok", "query {}")

    assert data == {"locations": {"edges": []}}


def test_shopify_graphql_http_error():
    mock_resp = MagicMock()
    mock_resp.status_code = 401
    mock_resp.json.return_value = {"errors": "unauthorized"}

    with patch("AdminApp.routers.shopify.requests.post", return_value=mock_resp):
        with pytest.raises(ShopifyAPIError) as exc_info:
            shopify_graphql("test-store.myshopify.com", "bad-tok", "query {}")

    assert exc_info.value.status_code == 401


def test_shopify_graphql_graphql_level_errors():
    """GraphQL returns HTTP 200 even when the query itself failed — the
    real error lives in the `errors` array, which must be checked
    separately from the HTTP status code."""
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.json.return_value = {"errors": [{"message": "field not found"}]}

    with patch("AdminApp.routers.shopify.requests.post", return_value=mock_resp):
        with pytest.raises(ShopifyAPIError) as exc_info:
            shopify_graphql("test-store.myshopify.com", "tok", "query { bad }")

    assert exc_info.value.status_code == 502


def test_shopify_graphql_network_error():
    import requests as req

    with patch(
        "AdminApp.routers.shopify.requests.post",
        side_effect=req.RequestException("timeout"),
    ):
        with pytest.raises(ShopifyAPIError) as exc_info:
            shopify_graphql("test-store.myshopify.com", "tok", "query {}")

    assert exc_info.value.status_code == 500


# ═══════════════════════════════════════════════════════════════════════════
# ROUTES
# ═══════════════════════════════════════════════════════════════════════════

# ── 1. GET /shopify/app ──────────────────────────────────────────────────────


def test_shopify_app_valid_hmac_returns_html_with_csp():
    with patch.object(shopify, "SHOPIFY_CLIENT_SECRET", _TEST_SECRET):
        params = {"shop": "test-store.myshopify.com", "timestamp": "123"}
        valid_hmac = _compute_app_load_hmac(params, _TEST_SECRET)
        request = _mock_request(query_params={**params, "hmac": valid_hmac})

        response = shopify_app(request)

    assert response.status_code == 200
    # CSP frame-ancestors is required by Shopify App Store review — a
    # missing/wrong header here is a real review-failure risk, so it's
    # worth asserting explicitly rather than just "did it return HTML".
    assert "frame-ancestors" in response.headers["content-security-policy"]
    assert "test-store.myshopify.com" in response.headers["content-security-policy"]


def test_shopify_app_invalid_hmac_raises_400():
    with patch.object(shopify, "SHOPIFY_CLIENT_SECRET", _TEST_SECRET):
        request = _mock_request(
            query_params={"shop": "test-store.myshopify.com", "hmac": "bad-hmac"}
        )

        with pytest.raises(HTTPException) as exc_info:
            shopify_app(request)

    assert exc_info.value.status_code == 400


def test_shopify_app_non_myshopify_domain_raises_400():
    with patch.object(shopify, "SHOPIFY_CLIENT_SECRET", _TEST_SECRET):
        params = {"shop": "evil.example.com"}
        valid_hmac = _compute_app_load_hmac(params, _TEST_SECRET)
        request = _mock_request(query_params={**params, "hmac": valid_hmac})

        with pytest.raises(HTTPException) as exc_info:
            shopify_app(request)

    assert exc_info.value.status_code == 400


# ── 2. POST /shopify/auth/token ──────────────────────────────────────────────


def test_exchange_missing_session_token_raises_400():
    request = _mock_request(headers={})
    session = MagicMock()

    with pytest.raises(HTTPException) as exc_info:
        exchange(request=request, session=session, body=None)

    assert exc_info.value.status_code == 400


def test_exchange_invalid_session_token_raises_401():
    request = _mock_request(headers={"Authorization": "Bearer bad-token"})
    session = MagicMock()

    with patch.object(
        shopify, "verify_session_token", side_effect=Exception("bad token")
    ):
        with pytest.raises(HTTPException) as exc_info:
            exchange(request=request, session=session, body=None)

    assert exc_info.value.status_code == 401


def test_exchange_no_shop_domain_in_claims_raises_400():
    request = _mock_request(headers={"Authorization": "Bearer some-token"})
    session = MagicMock()

    with patch.object(shopify, "verify_session_token", return_value={"sub": "x"}):
        with patch.object(shopify, "extract_shop_domain", return_value=None):
            with pytest.raises(HTTPException) as exc_info:
                exchange(request=request, session=session, body=None)

    assert exc_info.value.status_code == 400


def test_exchange_already_connected_with_valid_token_skips_shopify_call():
    future = datetime.now(timezone.utc).replace(tzinfo=None) + timedelta(hours=1)
    store = _mock_store_connected(access_token_expires_at=future)
    request = _mock_request(headers={"Authorization": "Bearer some-token"})
    session = MagicMock()
    session.exec.return_value.first.return_value = store

    with patch.object(shopify, "verify_session_token", return_value={"dest": "x"}):
        with patch.object(
            shopify, "extract_shop_domain", return_value="test-store.myshopify.com"
        ):
            with patch.object(shopify, "exchange_session_token") as mock_exchange:
                result = exchange(request=request, session=session, body=None)
                mock_exchange.assert_not_called()  # avoided a redundant Shopify call

    assert result.status_code == 200


def test_exchange_new_store_creates_and_saves():
    request = _mock_request(headers={"Authorization": "Bearer some-token"})
    session = MagicMock()
    session.exec.return_value.first.return_value = None  # no existing store

    token_data = {
        "access_token": "new-access-tok",
        "refresh_token": "new-refresh-tok",
        "expires_in": 3600,
        "refresh_token_expires_in": 7776000,
        "scope": "read_locations,read_orders",
    }

    with patch.object(shopify, "verify_session_token", return_value={"dest": "x"}):
        with patch.object(
            shopify, "extract_shop_domain", return_value="new-store.myshopify.com"
        ):
            with patch.object(
                shopify, "exchange_session_token", return_value=token_data
            ):
                result = exchange(request=request, session=session, body=None)

    assert result.status_code == 200
    session.add.assert_called_once()
    session.commit.assert_called_once()


def test_exchange_shopify_api_error_raises_502():
    request = _mock_request(headers={"Authorization": "Bearer some-token"})
    session = MagicMock()
    session.exec.return_value.first.return_value = None

    with patch.object(shopify, "verify_session_token", return_value={"dest": "x"}):
        with patch.object(
            shopify, "extract_shop_domain", return_value="test-store.myshopify.com"
        ):
            with patch.object(
                shopify,
                "exchange_session_token",
                side_effect=ShopifyAPIError(400, {"error": "invalid_grant"}),
            ):
                with pytest.raises(HTTPException) as exc_info:
                    exchange(request=request, session=session, body=None)

    assert exc_info.value.status_code == 502


def test_exchange_no_access_token_in_response_raises_502():
    request = _mock_request(headers={"Authorization": "Bearer some-token"})
    session = MagicMock()
    session.exec.return_value.first.return_value = None

    with patch.object(shopify, "verify_session_token", return_value={"dest": "x"}):
        with patch.object(
            shopify, "extract_shop_domain", return_value="test-store.myshopify.com"
        ):
            with patch.object(
                shopify, "exchange_session_token", return_value={"expires_in": 3600}
            ):
                with pytest.raises(HTTPException) as exc_info:
                    exchange(request=request, session=session, body=None)

    assert exc_info.value.status_code == 502


def test_exchange_accepts_body_fallback_when_no_auth_header():
    """The embedded page sends the session token via Authorization header,
    but the JSON body is a documented fallback — must work too."""
    request = _mock_request(headers={})
    session = MagicMock()
    session.exec.return_value.first.return_value = None
    body = ExchangeTokenRequest(session_token="tok-from-body")

    token_data = {"access_token": "tok", "expires_in": 3600, "scope": ""}

    with patch.object(
        shopify, "verify_session_token", return_value={"dest": "x"}
    ) as mock_verify:
        with patch.object(
            shopify, "extract_shop_domain", return_value="test-store.myshopify.com"
        ):
            with patch.object(
                shopify, "exchange_session_token", return_value=token_data
            ):
                exchange(request=request, session=session, body=body)

    mock_verify.assert_called_once_with("tok-from-body")


# ── 3. POST /shopify/link-shopify-store ───────────────────────────────────


def test_link_shopify_store_success():
    store = _mock_store()
    company = _mock_company()
    session = MagicMock()
    session.exec.return_value.first.return_value = store
    session.get.return_value = company
    body = LinkShopifyStoreRequest(shop_domain="test-store.myshopify.com", company_id=1)

    result = link_shopify_store(body=body, current_user=_ADMIN_USER, session=session)

    assert result["linked"] is True
    assert store.company_id == 1


def test_link_shopify_store_not_found():
    session = MagicMock()
    session.exec.return_value.first.return_value = None
    body = LinkShopifyStoreRequest(shop_domain="unknown.myshopify.com", company_id=1)

    with pytest.raises(HTTPException) as exc_info:
        link_shopify_store(body=body, current_user=_ADMIN_USER, session=session)

    assert exc_info.value.status_code == 404


def test_link_shopify_store_company_not_found():
    store = _mock_store()
    session = MagicMock()
    session.exec.return_value.first.return_value = store
    session.get.return_value = None
    body = LinkShopifyStoreRequest(
        shop_domain="test-store.myshopify.com", company_id=999
    )

    with pytest.raises(HTTPException) as exc_info:
        link_shopify_store(body=body, current_user=_ADMIN_USER, session=session)

    assert exc_info.value.status_code == 404


def test_link_shopify_store_already_linked_to_other_company():
    store = _mock_store(company_id=2)
    company = _mock_company(id=1)
    session = MagicMock()
    session.exec.return_value.first.return_value = store
    session.get.return_value = company
    body = LinkShopifyStoreRequest(shop_domain="test-store.myshopify.com", company_id=1)

    with pytest.raises(HTTPException) as exc_info:
        link_shopify_store(body=body, current_user=_ADMIN_USER, session=session)

    assert exc_info.value.status_code == 409


def test_link_shopify_store_relink_same_company_is_noop_success():
    store = _mock_store(company_id=1)
    company = _mock_company(id=1)
    session = MagicMock()
    session.exec.return_value.first.return_value = store
    session.get.return_value = company
    body = LinkShopifyStoreRequest(shop_domain="test-store.myshopify.com", company_id=1)

    result = link_shopify_store(body=body, current_user=_ADMIN_USER, session=session)

    assert result["linked"] is True


# ── 4. POST /shopify/unlink-shopify-store ─────────────────────────────────


def test_unlink_shopify_store_success():
    store = _mock_store(company_id=1)
    shop = _mock_shop(
        shopify_store_id=1, shopify_location_id_public="LOC1", use_shopify_public=True
    )
    session = MagicMock()
    session.get.return_value = store
    session.exec.return_value.all.return_value = [shop]

    result = unlink_shopify_store(
        body=UnlinkShopifyStoreRequest(shopify_store_id=1),
        current_user=_ADMIN_USER,
        session=session,
    )

    assert result["unlinked"] is True
    assert store.company_id is None
    assert shop.shopify_store_id is None
    assert shop.shopify_location_id_public is None
    assert shop.use_shopify_public is False


def test_unlink_shopify_store_not_found():
    session = MagicMock()
    session.get.return_value = None

    with pytest.raises(HTTPException) as exc_info:
        unlink_shopify_store(
            body=UnlinkShopifyStoreRequest(shopify_store_id=999),
            current_user=_ADMIN_USER,
            session=session,
        )

    assert exc_info.value.status_code == 404


# ── 5. GET /shopify/stores/available-to-connect ───────────────────────────


def test_get_available_to_connect_stores_returns_unlinked_only():
    store = _mock_store(id=1, company_id=None, disconnected_at=None)
    session = MagicMock()
    session.exec.return_value.all.return_value = [store]

    result = get_available_to_connect_stores(current_user=_ADMIN_USER, session=session)

    assert len(result) == 1
    assert result[0]["id"] == 1


def test_get_available_to_connect_stores_empty():
    session = MagicMock()
    session.exec.return_value.all.return_value = []

    result = get_available_to_connect_stores(current_user=_ADMIN_USER, session=session)

    assert result == []


# ── 6. GET /shopify/stores/by-company/{company_id} ────────────────────────


def test_get_store_by_company_returns_list():
    store1 = _mock_store(id=1)
    store2 = _mock_store(id=2, shopify_shop_domain="other-store.myshopify.com")
    session = MagicMock()
    session.exec.return_value.all.return_value = [store1, store2]

    result = get_store_by_company(
        company_id=5, current_user=_ADMIN_USER, session=session
    )

    assert len(result) == 2


def test_get_store_by_company_empty_list_when_none_linked():
    session = MagicMock()
    session.exec.return_value.all.return_value = []

    result = get_store_by_company(
        company_id=5, current_user=_ADMIN_USER, session=session
    )

    assert result == []


# ── 7. POST /shopify/webhooks/app/uninstalled ──────────────────────────────


def test_app_uninstalled_invalid_hmac_raises_401():
    request = _mock_request(body=b'{"id": 1}', headers={"X-Shopify-Hmac-Sha256": "bad"})
    session = MagicMock()

    with patch.object(shopify, "SHOPIFY_CLIENT_SECRET", _TEST_SECRET):
        with pytest.raises(HTTPException) as exc_info:
            _run_async(app_uninstalled(request=request, session=session))

    assert exc_info.value.status_code == 401


def test_app_uninstalled_valid_hmac_clears_tokens():
    store = _mock_store_connected(shopify_shop_domain="test-store.myshopify.com")
    body = b'{"id": 1}'
    session = MagicMock()
    session.exec.return_value.first.return_value = store

    with patch.object(shopify, "SHOPIFY_CLIENT_SECRET", _TEST_SECRET):
        valid_hmac = _compute_webhook_hmac(body, _TEST_SECRET)
        request = _mock_request(
            body=body,
            headers={
                "X-Shopify-Hmac-Sha256": valid_hmac,
                "X-Shopify-Shop-Domain": "test-store.myshopify.com",
            },
        )

        result = _run_async(app_uninstalled(request=request, session=session))

    assert result.status_code == 200
    assert store.shopify_access_token_encrypted is None
    assert store.shopify_refresh_token_encrypted is None
    assert store.disconnected_at is not None


def test_app_uninstalled_deletes_store_links():
    store = _mock_store_connected(id=1, shopify_shop_domain="test-store.myshopify.com")
    shopify_staff_links.save_link(1, 111, company_id=1, shop_id=None)
    shopify_staff_links.save_link(2, 222, company_id=2, shop_id=None)
    body = b'{"id": 1}'
    session = MagicMock()
    session.exec.return_value.first.return_value = store

    with patch.object(shopify, "SHOPIFY_CLIENT_SECRET", _TEST_SECRET):
        valid_hmac = _compute_webhook_hmac(body, _TEST_SECRET)
        request = _mock_request(
            body=body,
            headers={
                "X-Shopify-Hmac-Sha256": valid_hmac,
                "X-Shopify-Shop-Domain": "test-store.myshopify.com",
            },
        )

        result = _run_async(app_uninstalled(request=request, session=session))

    assert result.status_code == 200
    assert shopify_staff_links.get_link(1, 111) is None
    assert shopify_staff_links.get_link(2, 222) is not None  # other store untouched


def test_app_uninstalled_store_not_found_still_returns_200():
    body = b'{"id": 1}'
    session = MagicMock()
    session.exec.return_value.first.return_value = None

    with patch.object(shopify, "SHOPIFY_CLIENT_SECRET", _TEST_SECRET):
        valid_hmac = _compute_webhook_hmac(body, _TEST_SECRET)
        request = _mock_request(
            body=body,
            headers={
                "X-Shopify-Hmac-Sha256": valid_hmac,
                "X-Shopify-Shop-Domain": "unknown-store.myshopify.com",
            },
        )

        result = _run_async(app_uninstalled(request=request, session=session))

    # Always 200 once HMAC passes, even if there's nothing to do — Shopify
    # must never be given a reason to retry-storm this webhook.
    assert result.status_code == 200


def test_app_uninstalled_internal_exception_still_returns_200():
    body = b'{"id": 1}'
    session = MagicMock()
    session.exec.side_effect = RuntimeError("db exploded")

    with patch.object(shopify, "SHOPIFY_CLIENT_SECRET", _TEST_SECRET):
        valid_hmac = _compute_webhook_hmac(body, _TEST_SECRET)
        request = _mock_request(
            body=body,
            headers={
                "X-Shopify-Hmac-Sha256": valid_hmac,
                "X-Shopify-Shop-Domain": "test-store.myshopify.com",
            },
        )

        result = _run_async(app_uninstalled(request=request, session=session))

    assert result.status_code == 200


# ── 8. POST /shopify/webhooks/compliance ───────────────────────────────────


def test_compliance_webhook_invalid_hmac_raises_401():
    request = _mock_request(body=b"{}", headers={"X-Shopify-Hmac-Sha256": "bad"})
    session = MagicMock()

    with patch.object(shopify, "SHOPIFY_CLIENT_SECRET", _TEST_SECRET):
        with pytest.raises(HTTPException) as exc_info:
            _run_async(compliance_webhook(request=request, session=session))

    assert exc_info.value.status_code == 401


def test_compliance_webhook_data_request_logs_only_no_db_touch():
    body = b"{}"
    session = MagicMock()

    with patch.object(shopify, "SHOPIFY_CLIENT_SECRET", _TEST_SECRET):
        valid_hmac = _compute_webhook_hmac(body, _TEST_SECRET)
        request = _mock_request(
            body=body,
            headers={
                "X-Shopify-Hmac-Sha256": valid_hmac,
                "X-Shopify-Topic": "customers/data_request",
                "X-Shopify-Shop-Domain": "test-store.myshopify.com",
            },
        )

        result = _run_async(compliance_webhook(request=request, session=session))

    assert result.status_code == 200
    session.exec.assert_not_called()  # no data stored on our side to look up


def test_compliance_webhook_customers_redact_logs_only():
    body = b"{}"
    session = MagicMock()

    with patch.object(shopify, "SHOPIFY_CLIENT_SECRET", _TEST_SECRET):
        valid_hmac = _compute_webhook_hmac(body, _TEST_SECRET)
        request = _mock_request(
            body=body,
            headers={
                "X-Shopify-Hmac-Sha256": valid_hmac,
                "X-Shopify-Topic": "customers/redact",
                "X-Shopify-Shop-Domain": "test-store.myshopify.com",
            },
        )

        result = _run_async(compliance_webhook(request=request, session=session))

    assert result.status_code == 200


def test_compliance_webhook_shop_redact_deletes_store_and_clears_shops():
    store = _mock_store_connected(id=1, shopify_shop_domain="test-store.myshopify.com")
    shop = _mock_shop(
        shopify_store_id=1, shopify_location_id_public="LOC1", use_shopify_public=True
    )
    body = b"{}"
    session = MagicMock()
    session.exec.return_value.first.return_value = store
    session.exec.return_value.all.return_value = [shop]

    with patch.object(shopify, "SHOPIFY_CLIENT_SECRET", _TEST_SECRET):
        valid_hmac = _compute_webhook_hmac(body, _TEST_SECRET)
        request = _mock_request(
            body=body,
            headers={
                "X-Shopify-Hmac-Sha256": valid_hmac,
                "X-Shopify-Topic": "shop/redact",
                "X-Shopify-Shop-Domain": "test-store.myshopify.com",
            },
        )

        result = _run_async(compliance_webhook(request=request, session=session))

    assert result.status_code == 200
    assert shop.shopify_store_id is None
    assert shop.shopify_location_id_public is None
    assert shop.use_shopify_public is False
    session.delete.assert_called_once_with(store)


def test_compliance_webhook_shop_redact_store_not_found_no_error():
    body = b"{}"
    session = MagicMock()
    session.exec.return_value.first.return_value = None

    with patch.object(shopify, "SHOPIFY_CLIENT_SECRET", _TEST_SECRET):
        valid_hmac = _compute_webhook_hmac(body, _TEST_SECRET)
        request = _mock_request(
            body=body,
            headers={
                "X-Shopify-Hmac-Sha256": valid_hmac,
                "X-Shopify-Topic": "shop/redact",
                "X-Shopify-Shop-Domain": "unknown-store.myshopify.com",
            },
        )

        result = _run_async(compliance_webhook(request=request, session=session))

    assert result.status_code == 200
    session.delete.assert_not_called()


def test_compliance_webhook_unknown_topic_is_noop_200():
    body = b"{}"
    session = MagicMock()

    with patch.object(shopify, "SHOPIFY_CLIENT_SECRET", _TEST_SECRET):
        valid_hmac = _compute_webhook_hmac(body, _TEST_SECRET)
        request = _mock_request(
            body=body,
            headers={
                "X-Shopify-Hmac-Sha256": valid_hmac,
                "X-Shopify-Topic": "some/unrecognized-topic",
                "X-Shopify-Shop-Domain": "test-store.myshopify.com",
            },
        )

        result = _run_async(compliance_webhook(request=request, session=session))

    assert result.status_code == 200


def test_compliance_webhook_internal_exception_still_returns_200():
    body = b"{}"
    session = MagicMock()
    session.exec.side_effect = RuntimeError("db exploded")

    with patch.object(shopify, "SHOPIFY_CLIENT_SECRET", _TEST_SECRET):
        valid_hmac = _compute_webhook_hmac(body, _TEST_SECRET)
        request = _mock_request(
            body=body,
            headers={
                "X-Shopify-Hmac-Sha256": valid_hmac,
                "X-Shopify-Topic": "shop/redact",
                "X-Shopify-Shop-Domain": "test-store.myshopify.com",
            },
        )

        result = _run_async(compliance_webhook(request=request, session=session))

    assert result.status_code == 200


# ── 9. GET /shopify/locations ────────────────────────────────────────────


def test_get_locations_by_company_merges_multiple_stores():
    store1 = _mock_store_connected(id=1, shopify_shop_domain="store-a.myshopify.com")
    store2 = _mock_store_connected(id=2, shopify_shop_domain="store-b.myshopify.com")
    session = MagicMock()
    session.exec.return_value.all.return_value = [store1, store2]

    graphql_response = {
        "locations": {
            "edges": [
                {"node": {"legacyResourceId": "111", "name": "Loc A", "isActive": True}}
            ]
        }
    }

    with patch.object(shopify, "ensure_valid_shopify_token", return_value="tok"):
        with patch.object(shopify, "shopify_graphql", return_value=graphql_response):
            result = get_locations_by_company(
                company_id=1, current_user=_ADMIN_USER, session=session
            )

    assert len(result) == 2  # one location per store, both merged
    assert result[0]["store_domain"] == "store-a.myshopify.com"
    assert result[1]["store_domain"] == "store-b.myshopify.com"


def test_get_locations_by_company_no_stores_raises_404():
    session = MagicMock()
    session.exec.return_value.all.return_value = []

    with pytest.raises(HTTPException) as exc_info:
        get_locations_by_company(
            company_id=999, current_user=_ADMIN_USER, session=session
        )

    assert exc_info.value.status_code == 404


def test_get_locations_by_company_one_store_failing_doesnt_hide_others():
    store1 = _mock_store_connected(id=1, shopify_shop_domain="store-a.myshopify.com")
    store2 = _mock_store_connected(id=2, shopify_shop_domain="store-b.myshopify.com")
    session = MagicMock()
    session.exec.return_value.all.return_value = [store1, store2]

    graphql_response = {
        "locations": {
            "edges": [
                {"node": {"legacyResourceId": "222", "name": "Loc B", "isActive": True}}
            ]
        }
    }

    with patch.object(shopify, "ensure_valid_shopify_token", return_value="tok"):
        with patch.object(
            shopify,
            "shopify_graphql",
            side_effect=[ShopifyAPIError(502, "store A failed"), graphql_response],
        ):
            result = get_locations_by_company(
                company_id=1, current_user=_ADMIN_USER, session=session
            )

    assert len(result) == 1
    assert result[0]["store_domain"] == "store-b.myshopify.com"


# ── 10. POST /shopify/shop/connect ───────────────────────────────────────────


def test_connect_shop_shopify_success():
    shop = _mock_shop()
    store = _mock_store_connected(id=1)
    session = MagicMock()
    session.get.return_value = shop
    session.exec.return_value.all.side_effect = [[store]]
    session.exec.return_value.first.return_value = None  # no clash

    graphql_response = {
        "locations": {
            "edges": [
                {
                    "node": {
                        "legacyResourceId": "91019706622",
                        "name": "Loc A",
                        "isActive": True,
                    }
                }
            ]
        }
    }

    with patch.object(shopify, "ensure_valid_shopify_token", return_value="tok"):
        with patch.object(shopify, "shopify_graphql", return_value=graphql_response):
            result = connect_shop_shopify(
                shop_id=1,
                location_id="91019706622",
                current_user=_ADMIN_USER,
                session=session,
            )

    assert result["status"] == "connected"
    assert shop.shopify_store_id == 1
    assert shop.use_shopify_public is True


def test_connect_shop_shopify_shop_not_found():
    session = MagicMock()
    session.get.return_value = None

    with pytest.raises(HTTPException) as exc_info:
        connect_shop_shopify(
            shop_id=999, location_id="LOC1", current_user=_ADMIN_USER, session=session
        )

    assert exc_info.value.status_code == 404


def test_connect_shop_shopify_company_not_connected():
    shop = _mock_shop()
    session = MagicMock()
    session.get.return_value = shop
    session.exec.return_value.all.return_value = []  # no stores for this company

    with pytest.raises(HTTPException) as exc_info:
        connect_shop_shopify(
            shop_id=1, location_id="LOC1", current_user=_ADMIN_USER, session=session
        )

    assert exc_info.value.status_code == 400


def test_connect_shop_shopify_location_clash():
    shop = _mock_shop()
    store = _mock_store_connected(id=1)
    other_shop = _mock_shop(id=2, shopify_location_id_public="LOC1")
    session = MagicMock()
    session.get.return_value = shop
    session.exec.return_value.all.side_effect = [[store]]
    session.exec.return_value.first.return_value = other_shop  # clash

    with pytest.raises(HTTPException) as exc_info:
        connect_shop_shopify(
            shop_id=1, location_id="LOC1", current_user=_ADMIN_USER, session=session
        )

    assert exc_info.value.status_code == 409


def test_connect_shop_shopify_resolves_correct_store_among_multiple():
    """A company has two stores; the requested location only exists on the
    second one. connect_shop_shopify must search both, not assume the first."""
    shop = _mock_shop()
    store_a = _mock_store_connected(id=1, shopify_shop_domain="store-a.myshopify.com")
    store_b = _mock_store_connected(id=2, shopify_shop_domain="store-b.myshopify.com")
    session = MagicMock()
    session.get.return_value = shop
    session.exec.return_value.all.side_effect = [[store_a, store_b]]
    session.exec.return_value.first.return_value = None  # no clash

    empty_response = {"locations": {"edges": []}}
    match_response = {
        "locations": {
            "edges": [
                {"node": {"legacyResourceId": "999", "name": "Loc B", "isActive": True}}
            ]
        }
    }

    with patch.object(shopify, "ensure_valid_shopify_token", return_value="tok"):
        with patch.object(
            shopify, "shopify_graphql", side_effect=[empty_response, match_response]
        ):
            result = connect_shop_shopify(
                shop_id=1, location_id="999", current_user=_ADMIN_USER, session=session
            )

    assert result["status"] == "connected"
    assert shop.shopify_store_id == 2  # correctly matched to store_b, not store_a


def test_connect_shop_shopify_invalid_location_id():
    shop = _mock_shop()
    store = _mock_store_connected(id=1)
    session = MagicMock()
    session.get.return_value = shop
    session.exec.return_value.all.side_effect = [[store]]
    session.exec.return_value.first.return_value = None

    empty_response = {"locations": {"edges": []}}

    with patch.object(shopify, "ensure_valid_shopify_token", return_value="tok"):
        with patch.object(shopify, "shopify_graphql", return_value=empty_response):
            with pytest.raises(HTTPException) as exc_info:
                connect_shop_shopify(
                    shop_id=1,
                    location_id="NONEXISTENT",
                    current_user=_ADMIN_USER,
                    session=session,
                )

    assert exc_info.value.status_code == 400


# ── 11. DELETE /shopify/shop/disconnect ─────────────────────────────────────


def test_disconnect_shop_shopify_success():
    shop = _mock_shop(
        shopify_store_id=1, shopify_location_id_public="LOC1", use_shopify_public=True
    )
    session = MagicMock()
    session.get.return_value = shop

    result = disconnect_shop_shopify(
        shop_id=1, current_user=_ADMIN_USER, session=session
    )

    assert result["status"] == "disconnected"
    assert shop.shopify_store_id is None
    assert shop.shopify_location_id_public is None
    assert shop.use_shopify_public is False


def test_disconnect_shop_shopify_shop_not_found():
    session = MagicMock()
    session.get.return_value = None

    with pytest.raises(HTTPException) as exc_info:
        disconnect_shop_shopify(shop_id=999, current_user=_ADMIN_USER, session=session)

    assert exc_info.value.status_code == 404


def test_disconnect_shop_shopify_idempotent():
    """Calling disconnect on an already-disconnected shop should succeed
    cleanly, not error — matches square.py's unguarded disconnect pattern."""
    shop = _mock_shop(
        shopify_store_id=None, shopify_location_id_public=None, use_shopify_public=False
    )
    session = MagicMock()
    session.get.return_value = shop

    result = disconnect_shop_shopify(
        shop_id=1, current_user=_ADMIN_USER, session=session
    )

    assert result["status"] == "disconnected"


# Regression tests for the 3 PR-review fixes. Append to test_shopify.py.


def test_hmac_empty_secret_fails_closed():
    with patch.object(shopify, "SHOPIFY_CLIENT_SECRET", ""):
        assert verify_app_load_hmac({"shop": "x.myshopify.com", "hmac": "any"}) is False
        assert verify_webhook_hmac(b"{}", "any") is False


def test_get_locations_by_company_broken_store_doesnt_hide_others():
    broken = _mock_store(id=1, shopify_shop_domain="broken.myshopify.com")
    healthy = _mock_store_connected(id=2, shopify_shop_domain="healthy.myshopify.com")
    session = MagicMock()
    session.exec.return_value.all.return_value = [broken, healthy]

    response = {
        "locations": {
            "edges": [
                {"node": {"legacyResourceId": "555", "name": "Loc", "isActive": True}}
            ]
        }
    }

    def fake_token(store, _s):
        if store.id == 1:
            raise HTTPException(status_code=400, detail="not connected")
        return "tok"

    with patch.object(shopify, "ensure_valid_shopify_token", side_effect=fake_token):
        with patch.object(shopify, "shopify_graphql", return_value=response):
            result = get_locations_by_company(
                company_id=1, current_user=_ADMIN_USER, session=session
            )

    assert len(result) == 1
    assert result[0]["store_domain"] == "healthy.myshopify.com"


def test_connect_shop_shopify_clash_scoped_to_company():
    """clash query must filter by company_id, or a matching location_id in
    an unrelated company would wrongly block this connection."""
    shop = _mock_shop(id=1, company_id=1)
    store = _mock_store_connected(id=1)
    session = MagicMock()
    session.get.return_value = shop
    session.exec.return_value.all.side_effect = [[store]]
    session.exec.return_value.first.return_value = None

    response = {
        "locations": {
            "edges": [
                {"node": {"legacyResourceId": "888", "name": "Loc", "isActive": True}}
            ]
        }
    }

    with patch.object(shopify, "ensure_valid_shopify_token", return_value="tok"):
        with patch.object(shopify, "shopify_graphql", return_value=response):
            connect_shop_shopify(
                shop_id=1, location_id="888", current_user=_ADMIN_USER, session=session
            )

    clash_query = next(
        str(c.args[0])
        for c in session.exec.call_args_list
        if "shopify_location_id_public" in str(c.args[0])
    )
    assert "company_id" in clash_query
